# AGENTS.md

## 1. 项目定位

WorldForge 是面向单个作者的本地长篇写作工作站。当前仓库以 V6.6 一致性冻结方案为唯一产品基线。

权威资料按以下顺序生效：

1. 用户当前任务中的明确指令。
2. `docs/tasks/<TASK-ID>.md` 当前任务卡。
3. `docs/specs/WorldForge_V6.6_一致性收敛冻结最终工程设计文档.docx`。
4. `docs/WorldForge_AI编程全流程技术开发指南.md`。
5. 本文件。
6. 现有代码与历史实现。

发现代码、迁移、测试或文档与冻结方案冲突时，不得沿用旧实现掩盖冲突；必须在本次任务中修正，或明确记录为阻塞项。

## 2. 产品边界

V1.0 只实现单作者本地写作闭环：

```text
创建项目
→ 规划人物、设定、大纲、章节与场景
→ 块级正文编辑
→ AI 生成 Candidate
→ 作者比较、局部采用或丢弃
→ 定稿为不可变 Version
→ 确认章节状态与连续性
→ 搜索、校对、备份、恢复与导出
```

AI 仅允许两种接入方式：

1. Core 直接调用用户配置的兼容模型 API。
2. 在 WorldForge 本地工作空间中下载或导入受控的模型/服务包，由本机启动并通过回环地址调用。

作品、数据库、索引、日志、备份、配置、模型包和运行记录均保存在用户本机。不得建设 WorldForge 云存储、云同步、账号后台、作品托管或请求中转服务。

以下内容不属于当前产品：向量数据库、Embedding/Rerank、MCP 内部总线、CRDT、多人协作、插件市场、自动平台发布、读者运营分析、自动偏好学习、无人审核批量生成、云端遥测、CI/CD 发布平台与运维体系。

V1.5 仅在独立任务卡批准后实现超长篇分层记忆与本地 AI 项目日记；不得提前预建向量接口或破坏 V1.0 数据模型。

## 3. 不可破坏的不变量

### INV-001 本地数据边界

项目正文、设定、索引、日志、备份、配置和模型运行资产只写入本机。外部 API 请求只发送当前任务所需的最小上下文，且不经过 WorldForge 服务器。

### INV-002 AI 接入边界

Provider 只能是 `user_api` 或 `local_workspace_service`。新增第三种接入模式必须先修改冻结设计和任务卡。

### INV-003 Candidate 隔离

任何 AI 生成或改写文本都先成为 Candidate。包括单段快速改写在内，未经作者明确接受不得修改活动 Draft。

### INV-004 单一数据真源

每个项目的 `project.sqlite` 是正文、规划、状态、候选和版本的唯一权威来源。Renderer 状态、Tiptap 文档、FTS 索引、缓存、摘要、日记和导出文件均为可重建或派生数据。

### INV-005 代码硬约束

锁定块、Revision、不可变 Version、项目边界、路径边界、Candidate 接受条件和状态确认必须由 Core 代码校验。Prompt 和前端按钮不是安全控制。

### INV-006 作者裁决

AI 可以提出文本、校验问题、状态变化、摘要与项目日记，但不能直接修改权威设定、确认状态或定稿正文。

任一不变量测试失败都阻止任务完成与合并。

## 4. 运行架构

```text
Electron Main
  ├─ 窗口、生命周期、系统对话框、外链、Core 监管
  └─ 本地服务进程启动授权与异常回收

Preload
  └─ 只暴露命名且经过校验的最小 API

Renderer
  ├─ React + Tiptap + Zustand
  └─ 仅负责界面、编辑事务、临时流式显示与用户操作

Core Service Utility Process
  ├─ 唯一 SQLite 写入者
  ├─ Repository / Use Case / FTS5 / 校验 / 导入导出 / 备份
  ├─ Provider 调用与 GenerationRun
  └─ 本地服务包下载、校验、启动、健康检查与停止

Optional Local AI Service
  └─ 仅绑定 127.0.0.1，由本地服务清单约束
```

Renderer 禁止访问 Node、文件系统、SQLite、环境变量、凭据或原始 IPC 通道。

Core 初期保持单一 Utility Process。数据库写入串行化；AI 流式任务异步化；大型 Diff、DOCX 解析和压缩任务使用受控 worker。没有量化证据和批准任务，不拆分新的 WorldForge 常驻进程。

## 5. 仓库结构

```text
apps/desktop/main
apps/desktop/preload
apps/desktop/renderer

packages/contracts
packages/domain
packages/core-service
packages/editor-core
packages/prompts
packages/local-ai-service
packages/testkit

migrations/app
migrations/project

tests/unit
tests/integration
tests/e2e
tests/security
tests/migration
tests/performance

docs/specs
docs/tasks
docs/decisions
docs/test-evidence

evals
scripts
```

职责边界：

- `contracts`：Zod Schema、IPC 输入输出、错误码、事件信封；不放业务实现。
- `domain`：实体、不变量、纯函数；不依赖 Electron、React、SQLite。
- `core-service`：Repository、Use Case、写队列、Provider、FTS、备份、导入导出。
- `editor-core`：Tiptap Schema、Block Patch、锁定、logicalBlockId 映射。
- `prompts`：Prompt 版本、约束包、结构化输出解析；不直接访问数据库。
- `local-ai-service`：本地服务包清单、下载校验、进程生命周期和资源限制。
- `testkit`：临时项目、Provider Stub、故障注入、长文本夹具。

## 6. 技术规则

- TypeScript 开启 `strict`，禁止无理由使用 `any`；边界数据使用 `unknown` 后由 Zod 校验。
- 使用 pnpm workspace。
- UI 使用 React、Tiptap/ProseMirror、Zustand、Radix UI 与 Tailwind CSS。
- SQLite 仅由 Core 通过 `better-sqlite3` 访问。
- V1.0 检索只使用结构化关系和 SQLite FTS5，不创建向量抽象。
- 内部通信使用 Electron IPC 与 MessagePort，不搭建本地 HTTP 业务服务。
- API 密钥通过 Electron `safeStorage` 或系统凭据能力保存；不可进入 SQLite 明文、JSON 配置、日志或 Renderer 状态。
- 生产依赖新增前必须说明用途、替代方案、包体积、维护状态和许可证，并获得任务卡批准。
- 数据库迁移一经合并只允许追加，不得修改已发布迁移。

## 7. 数据与事务规则

项目数据库初始化必须执行：

```sql
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;
PRAGMA busy_timeout = 5000;
PRAGMA synchronous = NORMAL;
```

所有写操作进入单一写队列。以下操作必须是单事务：

- Draft Block Patch 与 Revision 增量。
- Candidate 接受、局部接受和融合。
- Version 创建。
- 章节拆分、合并和跨章移动。
- 状态提案确认或拒绝。
- 导入提交。
- 恢复点创建与恢复切换。
- 数据库迁移。

规则：

- 每章只有一个活动 Draft。
- 自动保存每次已提交事务只增加一次 Draft Revision。
- Revision 是并发控制号，不是完整快照。
- Version 与 VersionBlock 无业务更新路径。
- `logicalBlockId` 跨 Draft、Candidate、Version 保持逻辑身份。
- Candidate 接受前必须校验 `baseRevision`、块哈希、锁定状态、项目范围和目标章节。
- 接受 Candidate 后必须可整体撤销；应用重启后仍可恢复到接受前恢复点。
- FTS 索引损坏时应重建，不得反向覆盖权威表。

## 8. 编辑与 AI 规则

- Tiptap UI 锁定和 Core `LockGuard` 双层生效。
- AI、替换、拆分、合并、移动和批量操作均不得修改锁定块。
- 单段快速改写使用轻量 Candidate 内联审阅，不得绕过 Candidate 表。
- GenerationRun 状态仅为：`queued | running | succeeded | failed | cancelled`。
- 流式事件必须批量发送，带单调递增 `sequence`，不得逐 Token 发送 IPC。
- Renderer 中流式文本只是临时显示；完成后由 Core 持久化 Candidate。
- 取消反馈目标不超过 500 ms。
- 切换章节不得取消任务，也不得把流式内容混入其他章节。
- 展示给用户的阶段必须对应真实程序阶段，禁止伪造百分比和倒计时。
- 部分输出只能保存为 `partial` Candidate，默认不可直接接受，除非结构校验通过并由用户确认。

约束优先级：

```text
P0 代码不变量与锁定
P1 本章必须发生的事实
P2 当前权威状态与明确关联设定
P3 人物声音和作品风格
P4 补充背景
```

## 9. Electron 与本地服务安全

BrowserWindow 固定配置：

```ts
nodeIntegration: false
contextIsolation: true
sandbox: true
webSecurity: true
```

同时要求：

- Preload 只暴露命名方法，禁止暴露原始 `ipcRenderer.send/invoke`。
- 所有 IPC 输入输出由 Zod 校验。
- CSP 禁止任意脚本和远程页面。
- 应用内阻止远程导航和新窗口；外链由系统浏览器打开。
- 所有路径先规范化，再限制在活动项目、应用工作空间或用户明确选择的目录内。
- ZIP/DOCX 导入检查路径穿越、压缩炸弹、宏、OLE 与外链。
- 本地服务包必须有 Manifest、SHA-256、允许的可执行文件和启动参数；禁止任意 Shell 字符串。
- 本地 AI 服务只绑定回环地址；端口随机分配并验证进程归属。
- 子进程退出、应用崩溃或项目关闭时必须回收服务进程。

## 10. 界面与显示规则

视觉方向：安静的编辑工作台，正文始终是视觉中心。

- 支持浅色、深色、护眼和高对比主题。
- 正文版心为 680 / 760 / 860 CSS px 三档。
- 最低 1280×800；完整支持 2560×1440 的 100%、125%、150% 缩放与 21:9 超宽屏。
- 低于 1100 CSS px 时右侧栏改抽屉；低于 900 CSS px 时左右侧栏均改抽屉。
- 页面不得产生整体横向滚动。
- 超宽屏上的确认、删除、采用等危险操作保持靠近当前正文，不放到视线边缘。
- AI 内容来源使用中性灰或低饱和蓝紫，不用绿色表达“AI 更好”。
- 卡片只用于 Candidate、冲突、风险和恢复；普通信息使用分组与分隔线。
- 图标使用 SVG；交互动效控制在 120–200 ms；支持减少动态效果。

## 11. 标准执行流程

收到任务后按以下顺序执行，不得跳步：

1. 读取本文件、任务卡、相关设计章节、代码、测试、迁移和契约。
2. 复述目标、非目标、影响模块、数据/IPC 变化、风险与验证命令。
3. 任务范围明确时直接制定实施计划并继续；只有存在产品决策冲突、不可逆删除、凭据操作或超出任务范围时才停下询问。
4. 优先建立失败测试、最小复现或可量化基线。
5. 完成最小但闭环的实现；禁止无关重构。
6. 执行对应测试、构建和手动业务链路验证。
7. 审查 Diff，重点检查数据完整性、锁定、Revision、取消、失败、恢复、路径与权限。
8. 同步更新契约、迁移、文档和测试证据。
9. 输出实际命令、退出码、结果、变更文件、已知限制和剩余风险。

禁止用 TODO、空实现、假成功响应、硬编码演示数据、只写界面未接通数据流或只写测试桩来声称完成。

## 12. 必跑检查

所有任务完成前：

```bash
pnpm lint
pnpm typecheck
pnpm test
pnpm build
```

按变更类型追加：

| 变更 | 必跑命令 |
|---|---|
| 数据库或迁移 | `pnpm test:migration`、`pnpm test:integration` |
| Electron、Preload、IPC、安全 | `pnpm test:security`、`pnpm test:e2e` |
| 编辑器、锁定、Revision、Candidate、Version | `pnpm test:unit`、`pnpm test:integration`、`pnpm test:e2e` |
| Provider、Prompt、结构化输出、约束包 | `pnpm test:eval`、`pnpm test:integration` |
| 本地服务包与子进程 | `pnpm test:local-ai`、`pnpm test:security`、`pnpm test:integration` |
| 性能敏感路径 | `pnpm test:perf` |

数据库测试至少覆盖空库、当前库、旧版本升级和中断升级。高风险代码必须增加故障注入与恢复测试。

## 13. 硬性发布保证

以下事件必须保持为零：

- 锁定块被修改。
- 未确认 Candidate 写入 Draft。
- Revision 冲突时静默覆盖。
- AI 直接更新权威设定或确认状态。
- 跨项目写入或路径越界。
- API 密钥或正文进入默认日志。
- 本地服务绑定非回环地址。
- 未校验的服务包被执行。

模型生成质量评分不能替代这些代码保证。

## 14. 性能预算

- 2K 输入响应 P95 ≤ 50 ms。
- 自动保存提交 P95 ≤ 150 ms。
- 常规编辑 IPC P95 ≤ 200 ms。
- 取消反馈 ≤ 500 ms。
- 5000 中文字符 Candidate 首屏 Diff ≤ 500 ms，完整 Diff ≤ 1.2 s。
- 正文滚动 ≥ 50 fps。
- Core 单次事件循环阻塞 < 100 ms。
- 10 万字章节打开后首个可编辑状态 ≤ 2 s。

性能相关任务必须提交测量环境、数据规模、P50/P95 和回归对比。

## 15. 日志与隐私

默认日志可以记录：运行 ID、Provider/模型标识、耗时、Token 数、错误码、内容哈希和服务进程状态。

默认日志禁止记录：正文原文、完整 Prompt、API 密钥、凭据、附件内容和本地模型输入全文。

诊断包导出前必须展示清单并要求用户确认。

## 16. 完成定义

任务只有同时满足以下条件才可标记完成：

- 实现范围与任务卡、设计和非目标一致。
- 前端、IPC、Use Case、Repository 和数据库链路真实接通。
- 成功、失败、取消、冲突、恢复和权限路径均有验证。
- Schema、迁移、类型、实现、测试和文档同步。
- 必跑命令全部成功，并在 `docs/test-evidence/<TASK-ID>/` 保存证据。
- 已进行独立 Diff 审查；高风险任务完成第二次审查。
- 未留下无关重构、空实现、伪完成或未声明风险。

只完成分析、脚手架、Mock、界面静态稿或部分链路时，结论必须写“未完成”。
