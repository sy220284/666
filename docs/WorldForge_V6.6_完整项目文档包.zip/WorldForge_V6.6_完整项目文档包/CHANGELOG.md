# Changelog

## [Unreleased]

- 等待代码实施后记录。

## [V6.6 Documentation Baseline] - 2026-07-13

### Added

- 统一产品设计、技术开发指南和 Agent 工程规范。
- 建立需求、路线图、ADR、数据库、IPC、安全、测试、UI、用户、发布和验收文档体系。
- 建立 V1.0 任务卡与需求追踪矩阵。
- 建立证据目录和验收报告模板。

### Changed

- AI 接入统一为 `user_api` 与 `local_workspace_service` 两种模式。
- 快速改写统一进入 Candidate，不允许直接覆盖 Draft。
- V1.0 与 V1.5 分离；V1.5 不阻塞 V1.0。

### Removed from product scope

- 云存储、云同步、账号后台、WorldForge 请求中转。
- 向量数据库、Embedding、Rerank、MCP、CRDT、多人协作和插件市场。
- 自动发布、读者运营、自动偏好学习、无人审核批量生成和云端遥测。
