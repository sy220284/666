# WorldForge

WorldForge 是面向单个作者的本地长篇写作工作站。当前项目以 **WorldForge V6.6 一致性收敛冻结基线** 为唯一产品与工程依据。

## 核心边界

- 所有作品、数据库、索引、日志、备份、配置、模型包和运行记录只保存在用户本机。
- AI 只允许两种接入：`user_api` 与 `local_workspace_service`。
- 任何 AI 文本必须先形成 Candidate，作者确认后才能进入活动 Draft。
- `project.sqlite` 是单项目唯一权威数据源。
- V1.0 不包含云存储、云同步、账号后台、请求中转、向量数据库、多人协作、插件市场、自动发布、读者运营、自动偏好学习和无人审核批量生成。

## 权威文档

1. `docs/specs/WorldForge_V6.6_一致性收敛冻结最终工程设计文档.docx`
2. `docs/WorldForge_AI编程全流程技术开发指南.md`
3. `AGENTS.md`
4. 当前任务卡 `docs/tasks/<TASK-ID>.md`
5. 领域契约、迁移和自动化测试

完整文档关系见 `docs/INDEX.md`。

## 目标技术栈

Electron、React、TypeScript、Vite、Tiptap/ProseMirror、Zustand、Radix UI、Tailwind CSS、SQLite、better-sqlite3、Zod、Vitest、Playwright、pnpm workspace。

## 目标仓库结构

```text
apps/desktop/main
apps/desktop/preload
apps/desktop/renderer
packages/contracts
packages/domain
packages/core-service
packages/editor-core
packages/prompts
packages/local-ai-service
packages/testkit
migrations/app
migrations/project
tests
evals
docs
scripts
```

## 开发命令基线

```bash
pnpm install
pnpm dev
pnpm lint
pnpm typecheck
pnpm test
pnpm build
```

专项命令和完成标准见开发指南与任务卡。当前文档包是工程实施依据，不代表代码已经完成，也不包含伪造的测试结果。
