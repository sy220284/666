# Security Policy

## 适用范围

本文件规定 WorldForge 桌面应用、项目工作空间、导入文件、Provider 凭据和本地 AI 服务包的安全基线。

## 安全边界

- Renderer 处于不可信输入层，不具备 Node、文件系统、SQLite、环境变量和凭据访问能力。
- Preload 只暴露命名白名单 API，不暴露原始 IPC。
- Core Service 是唯一数据库写入者，负责项目、路径、Revision、锁定、Candidate 和 Version 校验。
- 本地 AI 服务只能从经过校验的本地服务包启动，并只绑定回环地址。

## 漏洞报告

正式公开仓库建立后，应通过仓库的私密安全报告渠道提交。报告应包含版本、平台、复现步骤、影响、最小样例和日志脱敏说明。不得在公开 Issue 中粘贴正文、API 密钥、完整 Prompt 或个人项目路径。

## 不接受的安全降级

不得为解决开发问题关闭 `sandbox`、`contextIsolation` 或 `webSecurity`；不得开放任意文件路径、Shell 字符串、远程导航、明文凭据和未校验的服务包执行。

详细威胁与控制见：

- `docs/security/THREAT_MODEL.md`
- `docs/security/DATA_FLOW_AND_PRIVACY.md`
- `docs/security/CREDENTIAL_HANDLING.md`
- `docs/security/LOCAL_AI_PACKAGE_SECURITY.md`
