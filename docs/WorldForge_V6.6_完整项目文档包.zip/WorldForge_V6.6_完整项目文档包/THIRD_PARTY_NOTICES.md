# Third-Party Notices

本文件在代码依赖锁定后由实际依赖清单生成并复核。

当前设计计划使用的主要第三方项目包括 Electron、React、TypeScript、Vite、Tiptap/ProseMirror、Zustand、Radix UI、Tailwind CSS、SQLite、better-sqlite3、Zod、Vitest、Playwright 和 pnpm。

正式发布前必须：

1. 从 lockfile 生成完整依赖及许可证清单。
2. 检查直接依赖、传递依赖、字体、图标、示例文件和本地服务包许可证。
3. 将必须保留的版权声明与许可证正文写入本文件或随包附带。
4. 阻止与项目许可证不兼容的依赖进入发布版本。

当前文件不声明尚未实际安装的依赖版本，也不替代最终许可证审计。
