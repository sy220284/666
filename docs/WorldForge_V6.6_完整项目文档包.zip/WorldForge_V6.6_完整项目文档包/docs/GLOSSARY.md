# 术语表

| 术语 | 定义 |
|---|---|
| Draft | 每章唯一的活动正文，可编辑，带单调递增 Revision。 |
| Candidate | AI 生成或改写的候选文本；作者接受前与 Draft 隔离。 |
| Version | 不可变章节快照，用于定稿、历史比较和恢复。 |
| logicalBlockId | 跨 Draft、Candidate、Version 追踪同一逻辑正文块的稳定标识。 |
| Revision | Draft 并发控制号；每次成功提交事务增加一次，不等于完整快照。 |
| GenerationRun | 一次 AI 生成运行，记录状态、真实阶段、Provider、取消和错误。 |
| Provider Profile | AI 连接配置；类型只能是 `user_api` 或 `local_workspace_service`。 |
| StateProposal | 规则或 AI 提出的动态状态变化，尚未成为当前权威状态。 |
| StateSnapshot | 作者确认后的章节尾状态快照。 |
| WriteQueue | Core 内所有 SQLite 写操作的串行队列。 |
| Recovery Point | Candidate 接受、导入、迁移等重大操作前创建的可恢复快照。 |
| FTS5 | SQLite 全文检索索引；属于可重建派生数据。 |
| T0 | 结构骨架候选，描述场景目标、冲突、转折、结果和风险。 |
| T1 | 基于已确认或编辑 T0 生成的正文候选。 |
| 权威数据 | 可决定当前正文、设定和状态的数据，保存在 `project.sqlite`。 |
| 派生数据 | 可从权威数据重建的信息，例如 FTS、摘要和项目日记。 |
