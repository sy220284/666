# WorldForge AI 编程全流程技术开发指南

> 适用基线：WorldForge V6.6《一致性收敛冻结最终工程设计文档》  
> 用途：把冻结产品方案转化为可由 Codex/其他编程 Agent 直接执行、验证和验收的工程任务  
> 交付目标：V1.0 本地长篇写作闭环；V1.5 超长篇分层记忆与本地 AI 项目日记  
> 核心原则：本地数据、双 AI 接入、Candidate 隔离、SQLite 权威、代码硬约束、作者裁决、证据化完成

---

## 0. 文档职责与冲突处理

本文件回答六个问题：

1. 产品采用什么架构，模块如何划分。
2. 技术栈为什么这样选，依赖如何约束。
3. 产品包含哪些功能，每项功能如何设计。
4. 每项功能在代码、数据库、IPC、界面中如何实现。
5. 实现完成后应达到什么可验证效果。
6. Codex 应按什么流程编码、测试、复查和交付。

权威顺序：

```text
用户当前明确指令
> 当前任务卡 docs/tasks/<TASK-ID>.md
> V6.6 冻结设计文档
> 本开发指南
> AGENTS.md
> 现有代码与历史实现
```

代码与冻结方案冲突时，以冻结方案为准。任务卡若需要改变产品边界，必须先更新设计文档、任务卡和 `AGENTS.md`，再改代码。

---

## 1. 冻结产品范围

### 1.1 V1.0 必须完成的闭环

```text
项目创建/打开
→ 作品任务书、人物、设定、大纲、章节、场景规划
→ 块级正文编辑、锁定、自动保存
→ AI 生成骨架、正文或局部改写 Candidate
→ 候选比较、逐块采用、融合、丢弃
→ 章节定稿为不可变 Version
→ 状态提案、时间线、知情、伏笔与章节尾快照
→ 搜索、校对、词典、批注、回收站
→ 本地备份、恢复、TXT/Markdown/DOCX 导入导出
```

### 1.2 AI 接入只允许两种模式

| 模式 | 说明 | 存储与调用边界 |
|---|---|---|
| `user_api` | 用户填写兼容 API 地址、模型名和凭据 | Core 从本机直连用户选定端点；凭据不进入 Renderer 和明文配置 |
| `local_workspace_service` | 下载或导入受控模型/服务包，在本地工作空间启动 | 模型、服务、日志、缓存均在本机；服务只监听回环地址 |

不建设 WorldForge 云端模型服务、请求中转、云存储或云同步。

### 1.3 当前产品不包含的内容

不实现向量数据库、Embedding/Rerank、MCP 内部总线、CRDT、多人协作、插件市场、自动发布、读者运营、自动偏好学习、无人审核批量生成、云端遥测、CI/CD 发布平台与运维系统。

这些内容不得以“为以后预留”为理由提前建立接口、表、进程或抽象层。

### 1.4 V1.5 独立范围

V1.5 只在 V1.0 稳定后立项：

- L0-L5 分层记忆。
- 时序状态历史账本。
- 章节、剧情弧和卷级摘要。
- 卷级检查点与失效传播。
- 手动、事件触发和应用内定时的 AI 项目日记。
- 300 万至 500 万字压力与召回测试。

V1.5 继续使用结构化关系与 FTS5，不引入向量检索。

---

## 2. 不可变工程约束

| 编号 | 约束 | 代码要求 | 验收证据 |
|---|---|---|---|
| INV-001 | 所有项目资产本地保存 | 项目目录、SQLite、索引、日志、备份、模型包均在本机 | 文件系统审计、无远端存储调用 |
| INV-002 | AI 只有两种接入模式 | Provider 类型为封闭联合类型 | Schema 测试拒绝第三种类型 |
| INV-003 | AI 文本先进入 Candidate | 任何生成/改写不直接 Patch Draft | 集成测试证明未接受时 Draft 不变 |
| INV-004 | `project.sqlite` 唯一权威 | Renderer/缓存/FTS 只读或可重建 | 删除缓存后可完整恢复 |
| INV-005 | 安全由 Core 代码强制 | 锁定、Revision、路径、项目范围由 Core 校验 | 故障与越权测试 |
| INV-006 | 作者确认权威状态 | AI 只写 Proposal/Derived Data | 无直接更新 canon/current state 的路径 |

任一不变量失败都不能以“功能大体可用”判定完成。

---

## 3. 总体架构

### 3.1 进程拓扑

```text
┌──────────────────────────────────────────────────────────────┐
│ Electron Main                                                │
│ 窗口/生命周期/系统对话框/外链/Core监管/本地服务进程授权       │
└───────────────┬──────────────────────────────────────────────┘
                │ 命名 IPC + MessagePort
┌───────────────▼──────────────────────────────────────────────┐
│ Preload                                                      │
│ 白名单 API、参数透传前校验、事件订阅释放                      │
└───────────────┬──────────────────────────────────────────────┘
                │ 类型化命令
┌───────────────▼──────────────────────────────────────────────┐
│ Renderer                                                     │
│ React / Tiptap / Zustand / Radix / Tailwind                  │
│ 界面、编辑事务、用户操作、临时流式显示                        │
└───────────────┬──────────────────────────────────────────────┘
                │ Zod 契约
┌───────────────▼──────────────────────────────────────────────┐
│ Core Service Utility Process                                 │
│ 单写 SQLite / Use Case / FTS5 / Provider / 校验 / 备份       │
│ 本地服务包下载、校验、启动、健康检查和回收                    │
└───────────────┬──────────────────────────────────────────────┘
                │ 仅 local_workspace_service 使用 127.0.0.1
┌───────────────▼──────────────────────────────────────────────┐
│ Optional Local AI Service                                    │
│ 受控可执行文件 + 模型，非 WorldForge 云服务                  │
└──────────────────────────────────────────────────────────────┘
```

### 3.2 各层职责

#### Electron Main

负责窗口、应用生命周期、系统菜单、文件选择器、外链打开、显示器恢复、Core 监管和本地服务子进程授权。

禁止保存正文、执行领域 SQL、解析 Prompt、直接修改项目状态。

#### Preload

只暴露业务级命名 API，例如：

```ts
window.worldforge.project.open(input)
window.worldforge.editor.applyPatch(input)
window.worldforge.ai.startGeneration(input)
window.worldforge.ai.subscribeRun(runId, handler)
```

禁止暴露通用 `send(channel, payload)`、Node 模块、文件句柄或路径写入能力。

#### Renderer

负责界面、Tiptap 编辑事务、临时选择状态、面板显示、用户确认和流式预览。

Renderer 不保存权威正文，不读取凭据，不直接访问数据库和文件系统。

#### Core Service

负责全部 Repository、Use Case、事务、Revision、锁定校验、Candidate、Version、状态提案、FTS5、导入导出、备份和 Provider 调用。

Core 是唯一 SQLite 写入者。

#### Optional Local AI Service

由 `local-ai-service` 模块根据 Manifest 启动，只绑定 `127.0.0.1`，通过兼容 HTTP API 与 Core 通信。服务退出不影响正文编辑；AI 功能进入可恢复失败状态。

### 3.3 内部并发模型

Core 初期保持一个 Utility Process，但内部划分三类执行通道：

1. `WriteQueue`：所有 SQLite 写操作串行执行。
2. `AsyncRunPool`：外部/本地模型流式调用和网络 I/O。
3. `WorkerPool`：大型 Diff、DOCX 解析、压缩、校验等 CPU 密集任务。

不得把同步 `better-sqlite3` 调用放在 Renderer 或 Main。不得让 AI 流式回调直接写数据库；完成事件进入 WriteQueue 后再持久化 Candidate。

---

## 4. 技术选型与约束

| 层级 | 技术 | 选型原因 | 实施约束 |
|---|---|---|---|
| 桌面壳 | Electron | 跨平台、成熟窗口/文件/进程能力 | 安全配置不可降低 |
| UI | React + TypeScript + Vite | 组件化、类型化、开发反馈快 | Renderer 无 Node 权限 |
| 编辑器 | Tiptap + ProseMirror | 支持结构化块、事务、插件和选区映射 | 只启用最小小说正文 Schema |
| UI 状态 | Zustand | 轻量、适合临时界面状态 | 不持久化权威正文 |
| 组件与样式 | Radix UI + Tailwind CSS | 无障碍原语与可控视觉系统 | 不使用大面积通用 SaaS 卡片风格 |
| 数据库 | SQLite + better-sqlite3 | 本地单文件、事务可靠、FTS5 可用 | 仅 Core 访问，单写队列 |
| 检索 | SQLite FTS5 + 结构化关系 | 不引入向量基础设施 | 索引为派生数据，可重建 |
| 契约 | Zod | 运行时校验和 TS 类型统一 | IPC、模型输出、Manifest 全部校验 |
| IPC | Electron IPC + MessagePort | 命令与流式事件分离 | 无内部 HTTP 服务 |
| 测试 | Vitest + Playwright | 单元/集成/桌面 E2E | 高风险路径需故障注入 |
| 凭据 | Electron `safeStorage` | 复用操作系统加密能力 | 降级时不允许明文持久化 |
| 本地服务 | `child_process.spawn` + Manifest | 支持本地工作空间部署 | 不接受 Shell 字符串，不绑定公网 |
| 包管理 | pnpm workspace | Monorepo 依赖清晰、缓存稳定 | lockfile 必须提交 |
| 本地构建 | Vite/Electron build 脚本 | 开发和本机验收 | 不建设发布平台、签名流水线和运维系统 |

所有版本在实施时锁定到 `pnpm-lock.yaml`。不要在设计文档中写易过期的具体版本号。

---

## 5. 目标仓库结构

```text
worldforge/
├── AGENTS.md
├── package.json
├── pnpm-workspace.yaml
├── tsconfig.base.json
├── eslint.config.js
├── apps/
│   └── desktop/
│       ├── main/
│       ├── preload/
│       └── renderer/
├── packages/
│   ├── contracts/
│   ├── domain/
│   ├── core-service/
│   ├── editor-core/
│   ├── prompts/
│   ├── local-ai-service/
│   └── testkit/
├── migrations/
│   ├── app/
│   └── project/
├── tests/
│   ├── unit/
│   ├── integration/
│   ├── e2e/
│   ├── security/
│   ├── migration/
│   └── performance/
├── evals/
├── docs/
│   ├── specs/
│   ├── tasks/
│   ├── decisions/
│   └── test-evidence/
└── scripts/
```

### 5.1 包依赖方向

```text
contracts  ← domain
     ↑          ↑
editor-core   prompts
     ↑          ↑
     └──── core-service ──── local-ai-service
                    ↑
              desktop main/preload
                    ↑
                 renderer
```

约束：

- `domain` 不依赖 Electron、React、SQLite。
- `contracts` 不放业务 Use Case。
- `prompts` 不直接查询数据库。
- `renderer` 不引用 `better-sqlite3`、`fs`、`path`、`child_process`。
- `local-ai-service` 不读取项目正文，只接收服务生命周期参数。

---

## 6. 数据架构

### 6.1 本地工作空间

```text
<WorldForgeWorkspace>/
├── app.sqlite
├── projects/
│   └── <project-id>/
│       ├── project.sqlite
│       ├── attachments/
│       ├── exports/
│       ├── backups/
│       ├── recovery/
│       └── temp/
├── local-services/
│   └── <service-id>/<version>/
│       ├── manifest.json
│       ├── bin/
│       ├── models/
│       └── logs/
└── logs/
```

`app.sqlite` 只保存应用级设置、项目注册表、窗口状态、Provider Profile 元数据和本地服务安装记录。作品正文与设定不进入 `app.sqlite`。

`project.sqlite` 保存单项目的全部权威数据。

### 6.2 数据库初始化

```sql
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;
PRAGMA busy_timeout = 5000;
PRAGMA synchronous = NORMAL;
```

启动时执行 `quick_check`。迁移、恢复和疑似损坏时执行 `integrity_check`。

### 6.3 核心表

| 领域 | 核心表 | 关键约束 |
|---|---|---|
| 项目结构 | `volumes`, `chapters`, `scenes` | 排序键稳定；软删除进入回收站 |
| 活动正文 | `drafts`, `draft_blocks` | 每章一个 Draft；Revision 单调递增 |
| AI 候选 | `candidates`, `candidate_blocks` | 必须记录 baseRevision、来源、状态 |
| 历史版本 | `versions`, `version_blocks` | 创建后不可更新 |
| 规划设定 | `story_brief`, `outlines`, `characters`, `locations`, `world_rules` | 作者编辑为权威 |
| 连续性 | `timeline_events`, `knowledge_states`, `foreshadows`, `state_snapshots`, `state_proposals` | Proposal 确认后才更新当前状态 |
| AI 运行 | `provider_profiles`, `generation_runs` | 凭据只存引用，不存明文 |
| 修订辅助 | `validation_issues`, `story_todos`, `comments`, `project_dictionary` | 可忽略、静音、恢复 |
| 文件流程 | `import_sessions`, `export_records`, `backup_records`, `trash_entries` | 提交与恢复有审计记录 |
| 派生数据 | `fts_*`, `summaries`, `project_diary_entries` | 可重建，不覆盖权威表 |

### 6.4 Draft、Candidate、Version

#### Draft

- 每章只有一个活动 Draft。
- `drafts.revision` 每次已提交编辑事务加一。
- `draft_blocks.logical_block_id` 在逻辑内容延续时保持稳定。
- 自动保存只提交已完成的 ProseMirror 事务，不保存半个 IME 组合状态。

#### Candidate

Candidate 类型：

```ts
type CandidateKind =
  | 'outline'
  | 'chapter_draft'
  | 'scene_draft'
  | 'inline_rewrite'
  | 'structural_rewrite'
  | 'merge';
```

Candidate 至少记录：

```ts
interface CandidateRecord {
  id: string;
  projectId: string;
  chapterId: string;
  kind: CandidateKind;
  status: 'complete' | 'partial' | 'accepted' | 'discarded' | 'conflicted';
  baseRevision: number;
  promptVersion: string;
  providerProfileId: string;
  generationRunId: string;
  createdAt: string;
}
```

#### Version

- 章节定稿、Candidate 接受前恢复点、重大结构操作前均可创建 Version。
- Version 与 VersionBlock 不允许业务 UPDATE。
- 恢复历史版本时复制成新 Draft，不修改旧 Version。

### 6.5 写队列

```ts
interface WriteQueue {
  execute<T>(label: string, task: (db: Database) => T): Promise<T>;
}
```

要求：

- 一个项目同一时刻只有一个写事务。
- 读操作可并发，但不得在长事务中执行模型调用、文件下载或 DOCX 解析。
- WriteQueue 记录任务名、等待时间、执行时间和失败码，不记录正文。
- 超过 100 ms 的同步工作应拆出事务外或移入 worker。

### 6.6 迁移规则

- 迁移文件按版本追加。
- 每个迁移在事务内执行。
- 迁移前创建一致性恢复点。
- 迁移失败时回滚并保持原数据库可打开。
- 测试覆盖空库、上一版本、多个历史版本和中断恢复。

---

## 7. IPC 与契约

### 7.1 通用请求信封

```ts
const RequestEnvelope = z.object({
  requestId: z.string().uuid(),
  projectId: z.string().uuid().optional(),
  expectedRevision: z.number().int().nonnegative().optional(),
  payload: z.unknown(),
});
```

### 7.2 通用响应

```ts
type Result<T> =
  | { ok: true; requestId: string; data: T }
  | {
      ok: false;
      requestId: string;
      error: {
        code: ErrorCode;
        message: string;
        retryable: boolean;
        details?: unknown;
      };
    };
```

### 7.3 错误码最小集合

```text
PROJECT_NOT_OPEN
PROJECT_SCOPE_VIOLATION
PATH_OUT_OF_SCOPE
REVISION_CONFLICT
LOCKED_BLOCK_MODIFICATION
CANDIDATE_BASE_MISMATCH
CANDIDATE_PARTIAL_INVALID
PROVIDER_UNAVAILABLE
PROVIDER_AUTH_FAILED
PROVIDER_OUTPUT_INVALID
LOCAL_SERVICE_PACKAGE_INVALID
LOCAL_SERVICE_START_FAILED
LOCAL_SERVICE_HEALTH_TIMEOUT
GENERATION_CANCELLED
IMPORT_UNSAFE_FILE
IMPORT_PARSE_FAILED
BACKUP_SPACE_INSUFFICIENT
DATABASE_INTEGRITY_FAILED
```

### 7.4 流式事件

```ts
type GenerationEvent =
  | { type: 'stage'; sequence: number; stage: GenerationStage }
  | { type: 'delta'; sequence: number; text: string }
  | { type: 'usage'; sequence: number; inputTokens?: number; outputTokens?: number }
  | { type: 'completed'; sequence: number; candidateId: string }
  | { type: 'failed'; sequence: number; code: ErrorCode }
  | { type: 'cancelled'; sequence: number; partialCandidateId?: string };
```

规则：

- 每 30-80 ms 或达到最小字符量批量发送 delta。
- `sequence` 严格递增，Renderer 丢弃重复或倒序事件。
- 页面卸载时释放订阅，不取消 GenerationRun。
- 重新进入页面可按 `runId` 重订阅并读取当前状态。

---

## 8. 功能实现总表

| ID | 功能 | 核心模块 | 主要数据 | 主要验收结果 |
|---|---|---|---|---|
| F01 | 项目与工作空间 | Core/Main | app.sqlite/project.sqlite | 创建、打开、移动、恢复不丢数据 |
| F02 | 规划系统 | Domain/Core/Renderer | brief/outlines/characters/scenes | 从最小信息进入第一章 |
| F03 | 块级编辑器 | editor-core/Core | drafts/draft_blocks | IME、安全保存、锁定、撤销可靠 |
| F04 | Candidate 与 Version | Core/editor-core | candidates/versions | AI 不覆盖 Draft，可局部采用与回退 |
| F05 | 用户 API Provider | Core/prompts | provider_profiles/runs | 连接测试、流式、取消、错误可见 |
| F06 | 本地工作空间服务 | local-ai-service/Core | service installs/runs | 下载/导入/校验/启动/停止闭环 |
| F07 | T0/T1/改写 | prompts/Core/Renderer | runs/candidates | 骨架、正文、局部改写结构化输出 |
| F08 | 连续性 | Domain/Core | timeline/knowledge/state/foreshadow | 当前事实可追踪，返修提示失效 |
| F09 | 校验与修订 | Core/Renderer | issues/todos/comments | 问题分级、静音、定位、复查 |
| F10 | 搜索、替换、词典、笔记 | Core/FTS | FTS/dictionary/notes | 全项目检索和安全批量替换 |
| F11 | 导入导出 | Core/worker | sessions/records | 预览后提交、失败回滚、原子导出 |
| F12 | 备份、恢复、回收站 | Core | backup/trash | 三轨备份、恢复、永久删除保护 |
| F13 | 设置、主题、高分屏 | Main/Renderer | app settings | 2K、混合 DPI、21:9 无横向溢出 |
| F14 | V1.5 记忆与项目日记 | Core/prompts | summaries/ledger/diary | 派生信息可追溯，不污染权威状态 |

---

## 9. F01 项目与工作空间

### 9.1 目标

作者能创建、打开、重命名、移动和关闭项目；异常退出后能恢复到最近已提交状态。

### 9.2 设计

- 项目目录由 Core 创建。
- `project.sqlite` 创建成功、Schema 初始化成功、Manifest 写入成功后，项目才登记到 `app.sqlite`。
- 移动项目采用“复制到临时目录 → 校验 → 原子切换注册路径 → 删除旧路径”的流程。
- 项目打开时获取项目级互斥锁，防止同一实例重复打开同一数据库。

### 9.3 实现

Use Case：

```text
CreateProject
OpenProject
CloseProject
MoveProject
RenameProject
RepairProjectRegistration
```

关键 IPC：

```text
project.create
project.open
project.close
project.move
project.rename
project.health
```

### 9.4 失败路径

- 目标目录无权限。
- 磁盘空间不足。
- 数据库损坏。
- 目录已存在且非空。
- 移动中断。
- 项目 ID 与注册表冲突。

### 9.5 验收效果

- 新建项目后目录和数据库结构完整。
- 中途失败不留下“可见但不可打开”的半项目。
- 移动中断后原路径仍可打开。
- Renderer 不能通过伪造路径打开工作空间外数据库。

---

## 10. F02 规划系统

### 10.1 功能范围

- 作品任务书：题材、核心冲突、主角目标、基本规则、目标字数。
- 大纲树：卷、阶段、章节、场景。
- 人物：身份、动机、关系、声音、静态设定、当前状态引用。
- 地点与世界规则。
- 场景卡：目标、冲突、转折、结果、参与人物、必须发生事实。

### 10.2 设计原则

- 新手向导和专业编辑共享同一数据模型。
- 规划信息不会自动改写正文。
- 已有正文关联的场景跨章移动必须确认并执行事务。
- 静态设定与动态状态分开存储。

### 10.3 实现

领域实体：

```ts
StoryBrief
OutlineNode
Volume
Chapter
Scene
Character
CharacterRelation
Location
WorldRule
```

排序使用可插入的 `sort_key`，避免每次拖拽重写整树。

场景卡与正文通过 `scene_id` 和 `logical_block_id` 关联。删除场景不会直接删除正文块；需要用户选择“仅解除关联”或“正文一并进入回收站”。

### 10.4 验收效果

- 五步向导只填写最少信息即可创建第一章。
- 专业模式可直接创建空项目并进入正文。
- 拖动大纲不修改历史 Version。
- 删除、移动、合并操作均有明确预览与恢复路径。

---

## 11. F03 块级正文编辑器

### 11.1 Schema

V1.0 只启用：

```text
doc
paragraph
heading(level 1-3)
blockquote
hardBreak
text
bold
italic
```

不支持复杂网页样式、任意字体、脚本、嵌入式 HTML 和远程图片。

### 11.2 块模型

每个顶级正文块对应 `draft_blocks` 一行：

```ts
interface DraftBlock {
  id: string;
  logicalBlockId: string;
  chapterId: string;
  sceneId?: string;
  orderKey: string;
  type: 'paragraph' | 'heading' | 'blockquote';
  contentJson: unknown;
  plainText: string;
  contentHash: string;
  locked: boolean;
}
```

### 11.3 编辑事务

Renderer 将 ProseMirror 事务转换为 `BlockPatch`：

```ts
type BlockPatchOp =
  | { op: 'insert'; afterLogicalBlockId?: string; block: NewBlock }
  | { op: 'update'; logicalBlockId: string; baseHash: string; block: UpdatedBlock }
  | { op: 'delete'; logicalBlockId: string; baseHash: string }
  | { op: 'move'; logicalBlockId: string; afterLogicalBlockId?: string };
```

Core 校验：

1. project/chapter 范围。
2. expectedRevision。
3. 每个 baseHash。
4. 锁定块。
5. orderKey 与结构合法性。
6. 单事务提交并增加 Revision。

### 11.4 自动保存

- 输入停止 500-900 ms 后提交已完成事务。
- IME composition 期间不提交。
- 切章、关窗和失焦时刷新待保存事务。
- 保存失败时保留 Renderer 未提交队列，显示明确重试入口。

### 11.5 锁定

- UI 插件阻止光标操作和删除锁定块。
- Core `LockGuard` 再次校验任何 Patch、Candidate 接受、拆并和替换。
- 锁定块在候选生成约束包中标记为不可更改。

### 11.6 验收效果

- 中文 IME 不丢字、不重复、不拆分错误。
- 断网不影响本地编辑。
- 自动保存失败时不假报成功。
- 锁定块通过 UI、IPC 伪造和批量操作都无法修改。
- 10 万字章节仍可在性能预算内编辑。

---

## 12. F04 Candidate、Diff、采用与 Version

### 12.1 Candidate 生成边界

所有 AI 输出，包括单段快速改写，都持久化为 Candidate。快速改写只缩短审阅界面，不改变数据安全路径。

### 12.2 Diff 算法

优先级：

1. 以 `logicalBlockId` 对齐块。
2. 新增、删除、移动、修改按块分类。
3. 块内文本使用字符/词级 Diff 辅助展示。
4. 无逻辑 ID 的模型输出先由结构映射器匹配；低置信度标记为冲突。

大型 Diff 在 worker 中执行；首屏优先返回可视区域结果。

### 12.3 接受计划

```ts
interface CandidateAcceptPlan {
  candidateId: string;
  chapterId: string;
  expectedRevision: number;
  operations: Array<{
    candidateLogicalBlockId: string;
    action: 'accept' | 'reject' | 'merge';
    mergedText?: string;
  }>;
}
```

Core 执行：

1. 重新读取 Candidate 和当前 Draft。
2. 校验 baseRevision、哈希和锁定。
3. 创建接受前恢复点。
4. 应用 Block Patch。
5. 增加 Revision。
6. 记录来源和接受映射。
7. 更新 Candidate 状态。
8. 单事务提交。

### 12.4 冲突

Revision 已变化时禁止自动重放。返回：

- 原 Candidate 基线。
- 当前 Draft。
- 可安全应用的块。
- 冲突块。

用户重新选择后生成新的 AcceptPlan。

### 12.5 Version

定稿操作创建不可变 Version，同时记录：

- draftRevision。
- 内容哈希。
- 章节字数。
- 来源 Candidate 列表。
- 状态快照版本。

### 12.6 验收效果

- Candidate 未接受前 Draft 字节级不变。
- 可逐块接受、全部接受、手工融合和丢弃。
- Revision 冲突不会静默覆盖新编辑。
- Ctrl/Cmd+Z 能整体撤销一次接受。
- 重启后可从接受前恢复点恢复。

---

## 13. F05 用户 API Provider

### 13.1 Provider Profile

```ts
type ProviderType = 'user_api' | 'local_workspace_service';

interface ProviderProfile {
  id: string;
  name: string;
  type: ProviderType;
  baseUrl: string;
  model: string;
  capabilities: {
    streaming: boolean;
    structuredOutput: boolean;
    maxContextTokens: number;
    maxOutputTokens: number;
  };
  credentialRef?: string;
  localServiceId?: string;
}
```

不得增加未经需求验证的能力标记。

### 13.2 凭据

- Renderer 只看到“已配置/未配置”。
- Main/Core 使用 `safeStorage` 加密凭据。
- OS 安全存储不可用时，允许仅会话内使用；禁止明文落盘。
- 日志只记录 Profile ID 和错误码。

### 13.3 连接测试

连接测试分三层：

1. URL 与协议格式。
2. 认证与模型可用性。
3. 最小结构化输出/流式能力探测。

测试不发送项目正文，只发送固定无隐私探针。

### 13.4 验收效果

- 错误密钥、无模型、超时、证书错误均显示可行动信息。
- 切换 Provider 不影响已保存 Candidate 和 Version。
- 默认日志与诊断包不含密钥和请求正文。

---

## 14. F06 本地工作空间模型/服务部署

### 14.1 产品边界

该功能解决“把模型或兼容服务部署在用户本机工作空间并供 Core 调用”。它不是通用容器平台、模型商店或 GPU 运维系统。

V1.0 最小能力：

- 从用户指定 URL 下载服务包，或从本地文件导入。
- 校验 Manifest、SHA-256、目录结构和平台匹配。
- 解压到本地工作空间临时目录，校验后原子安装。
- 启动受控可执行文件。
- 随机分配回环端口。
- 健康检查、状态展示、停止、崩溃恢复和卸载。
- 模型文件可随包导入，也可由 Manifest 声明独立下载项。

### 14.2 Manifest

```ts
const LocalServiceManifest = z.object({
  schemaVersion: z.literal(1),
  id: z.string().regex(/^[a-z0-9._-]+$/),
  version: z.string(),
  platform: z.enum(['win32-x64', 'darwin-arm64', 'darwin-x64', 'linux-x64']),
  executable: z.string(),
  args: z.array(z.string()),
  healthPath: z.string().startsWith('/'),
  apiBasePath: z.string().startsWith('/'),
  sha256: z.string().regex(/^[a-f0-9]{64}$/),
  files: z.array(z.object({
    path: z.string(),
    sha256: z.string().regex(/^[a-f0-9]{64}$/),
    size: z.number().int().nonnegative(),
  })),
  environment: z.record(z.string()).optional(),
  resourceHints: z.object({
    memoryMb: z.number().int().positive().optional(),
    gpuLayers: z.number().int().nonnegative().optional(),
  }).optional(),
});
```

### 14.3 安装安全

- 下载到 `.partial` 文件。
- 限制最大下载/解压大小。
- 禁止绝对路径、`..`、符号链接逃逸和重复覆盖。
- 校验包与每个文件哈希。
- `executable` 必须位于安装目录。
- 使用 `spawn(executable, args, { shell: false })`。
- 环境变量采用白名单，不继承敏感应用环境。
- 安装成功后原子重命名。

### 14.4 运行生命周期

状态：

```text
not_installed
installing
installed
starting
healthy
unhealthy
stopping
stopped
failed
```

启动流程：

1. 校验安装记录和文件哈希。
2. 分配空闲回环端口。
3. 构造参数，不拼接 Shell 命令。
4. 启动进程并记录 PID/启动令牌。
5. 在超时内轮询健康端点。
6. 健康后创建临时 Provider Profile。
7. 退出时清理 PID、端口和临时文件。

### 14.5 资源与故障

- 启动前检查磁盘空间和可用内存提示。
- 不自动修改显卡驱动或系统环境。
- 服务崩溃时最多受控重启一次；继续失败则保持编辑器可用并要求用户处理。
- 项目关闭时是否停止由应用级设置决定，默认停止。
- 应用异常退出后，下次启动检查并清理孤儿进程。

### 14.6 验收效果

- 损坏包、哈希不符、路径穿越、错误平台和非法可执行文件均被拒绝。
- 服务只监听 `127.0.0.1`。
- 应用关闭后无遗留孤儿进程。
- 本地服务不可用时正文编辑、搜索、备份继续可用。
- 用户可以卸载服务而不影响项目正文和历史 Candidate。

---

## 15. F07 T0、T1 与改写工作流

### 15.1 GenerationRun

```ts
type GenerationStatus =
  | 'queued'
  | 'running'
  | 'succeeded'
  | 'failed'
  | 'cancelled';
```

GenerationRun 记录：

- 任务类型。
- 项目、章节、选区。
- Provider Profile。
- Prompt 版本。
- 约束包哈希。
- 状态、时间、错误码、Token 统计。
- 最终 Candidate ID。

### 15.2 约束包组装

顺序固定：

```text
P0 锁定块、禁止修改范围、输出 Schema
P1 本章必须事实、场景目标、目标长度
P2 当前人物状态、时间线、知情、伏笔、明确关联设定
P3 人物声音、作品风格、禁用表达
P4 FTS5 补充背景
```

超过上下文预算时从 P4 开始裁剪；P0/P1 不可裁剪。

### 15.3 T0 骨架

输出结构：

```ts
interface ChapterSkeleton {
  goal: string;
  scenes: Array<{
    title: string;
    purpose: string;
    conflict: string;
    turn: string;
    outcome: string;
    requiredFacts: string[];
  }>;
  continuityRisks: string[];
}
```

T0 只形成 Candidate，不创建章节正文。

### 15.4 T1 正文

T1 基于作者选择或编辑后的 T0、当前上下文和目标字数生成块结构。输出解析失败时：

1. 尝试一次受控修复请求。
2. 修复失败则保存原始输出为不可接受的失败附件，不写 CandidateBlock。
3. 给出重试、换模型或手工复制入口。

### 15.5 快速改写

- 适用于一个自然段或一个逻辑块。
- 生成 `inline_rewrite` Candidate。
- UI 在原段附近展示原文、新文和差异。
- 用户一次确认后执行 Candidate 接受事务。
- 锁定块、跨场景和大幅结构变化自动升级为完整候选工作台。

### 15.6 取消与部分结果

- 取消信号传递到 Provider。
- 500 ms 内 UI 显示已取消或正在结束。
- 结构完整的部分输出可保存为 `partial` Candidate。
- `partial` 默认不可接受；通过 Schema 与块完整性校验后，用户可显式解锁审阅。

### 15.7 验收效果

- 切换章节后任务继续运行且不串流。
- 同一章节可并行查看多个 Candidate，但数据库写入仍串行。
- 取消、超时、限流、模型错误和结构错误均有明确状态。
- AI 无法绕过锁定和 Revision。

---

## 16. F08 连续性与状态确认

### 16.1 数据分层

| 类型 | 例子 | 权威来源 |
|---|---|---|
| 静态设定 | 人物身份、世界规则、地点固定属性 | 作者编辑的设定表 |
| 动态状态 | 位置、伤势、关系、持有物、知情 | 作者确认的状态记录 |
| 时间线 | 事件发生时间、顺序、持续时间 | 作者确认的事件 |
| 伏笔 | 埋设、目标回收章、状态 | 作者维护或确认 |
| 派生摘要 | 章节摘要、风险提示 | 可重建，不是权威 |

### 16.2 章节定稿流程

```text
创建 Version
→ 提取状态变化 Candidate
→ 连续性校验
→ 作者逐项确认/修改/拒绝
→ 写入 StateSnapshot 与状态表
→ 标记后续章节基线
```

状态提案和正文 Candidate 使用不同实体，但同样遵循作者确认。

### 16.3 返修传播

历史章节产生新 Version 时：

1. 比较旧/新定稿的状态影响。
2. 标记后续快照 `stale`。
3. 显示受影响章节和原因。
4. 不自动改写后续正文或状态。
5. 作者按范围重新确认。

### 16.4 知情信息

记录人物何时、通过什么来源知道某事实。生成约束包只向人物提供其已知内容。

### 16.5 伏笔

字段：埋设章、描述、目标回收范围、当前状态、证据块、提醒级别。超过目标范围未回收时进入 StoryTodo，不自动修改正文。

### 16.6 验收效果

- 模型不会把历史状态误当当前状态。
- 返修前章会提示后续影响，但不会自动连锁改稿。
- 每条状态、知情和伏笔可追溯到章节/块/作者确认记录。

---

## 17. F09 校验与修订

### 17.1 校验层级

1. 代码可确定：时间顺序、重复 ID、锁定违规、状态有效期冲突。
2. 规则校验：专名、标点、引号、重复符号、禁用词。
3. AI 辅助：人物行为、文风、逻辑、信息泄露风险。

AI 校验只生成 `ValidationIssue`，不改正文。

### 17.2 Issue 模型

```ts
interface ValidationIssue {
  id: string;
  projectId: string;
  chapterId: string;
  logicalBlockId?: string;
  type: string;
  severity: 'info' | 'warning' | 'error';
  message: string;
  evidence: string[];
  source: 'code' | 'rule' | 'ai';
  status: 'open' | 'resolved' | 'ignored';
}
```

### 17.3 降噪

- 本章忽略。
- 项目规则静音。
- 专名加入词典。
- 误报反馈只存本地规则，不自动学习作者偏好。
- 同一块同类问题合并。

### 17.4 验收效果

- 每个问题能定位到块并说明证据。
- AI 建议不伪装成确定事实。
- 忽略与静音规则可撤销。
- 修订后可重新运行并关闭已解决问题。

---

## 18. F10 搜索、替换、词典与笔记

### 18.1 FTS5

索引范围：Draft、已定稿 Version 的当前版本、人物、地点、规则、时间线、伏笔、笔记。

索引内容为派生数据。数据库恢复或 Schema 变化后可全量重建。

### 18.2 搜索

支持：

- 关键词与短语。
- 名称/别名。
- 章节、卷、实体、正文/设定范围过滤。
- 当前稿/定稿版本过滤。

### 18.3 安全批量替换

流程：搜索 → 结果预览 → 排除锁定块和历史 Version → 生成 Patch 计划 → 用户确认 → 单事务或分章事务提交 → 可撤销。

替换禁止作用于不可变 Version。

### 18.4 项目词典

保存专名、别名、允许拼写和禁用写法；供校对、搜索和 Prompt 使用。

### 18.5 研究笔记

只实现本地文本、标签、来源 URL/文件路径和实体/章节关联。不抓取网页，不做文献管理和自动可信度评分。

### 18.6 验收效果

- 删除 FTS 表后可重建并得到一致结果。
- 批量替换不会修改锁定块和历史版本。
- 结果预览数量与实际变更数量一致。

---

## 19. F11 导入与导出

### 19.1 导入流程

```text
选择文件
→ 安全扫描
→ 解析到 ImportSession 临时结构
→ 分章预览
→ 合并/拆分/重命名/调整层级
→ 用户确认
→ 创建导入前恢复点
→ 单事务写入项目
```

### 19.2 TXT/Markdown

- 检测 UTF-8、UTF-16、GB18030 等常见编码。
- 章节识别只作为建议，必须可手工调整。
- Markdown 只保留最小正文格式。

### 19.3 DOCX

- 拒绝含宏文档。
- 过滤 OLE、外链和远程资源。
- 限制 ZIP 展开大小、文件数量和嵌套深度。
- 按标题样式和段落解析，复杂表格、脚注和浮动对象给出明确降级报告。

### 19.4 导出

- TXT、Markdown、DOCX。
- 可选范围：全书、卷、章节、当前 Draft、指定 Version。
- 先写临时文件，校验成功后原子重命名。
- 导出失败不覆盖已有文件。

### 19.5 验收效果

- 导入取消或失败后项目无半写入数据。
- 预览中调整的章节结构与提交结果一致。
- 导出文件可重新打开，字符数与选择范围一致。

---

## 20. F12 备份、恢复与回收站

### 20.1 三轨备份

| 类型 | 触发 | 保存策略 |
|---|---|---|
| 日常滚动备份 | 应用内定时、达到编辑量、关闭项目 | 保留最近若干份，按空间上限轮换 |
| 重大操作恢复点 | 迁移、导入、批量替换、Candidate 接受、章节拆并 | 与操作关联，短期保留 |
| 手动快照 | 用户主动创建 | 用户明确删除前保留 |

数据库使用 SQLite Online Backup API 创建一致副本，附件清单和 Manifest 校验通过后再原子提交。

### 20.2 恢复

- 恢复前先对当前项目创建保护快照。
- 恢复包在隔离目录完成校验。
- 切换失败时回到原项目。
- 恢复后重建 FTS 和派生缓存。

### 20.3 回收站

卷、章、场景、笔记和附件先软删除。恢复时若父级不存在或名称冲突，提供目标位置和重命名选择。永久删除需要二次确认和项目范围校验。

### 20.4 验收效果

- 数据库写入中执行备份仍得到一致副本。
- 磁盘不足时不删除上一份有效备份。
- 恢复失败不破坏当前项目。
- 永久删除不能通过伪造 ID 删除其他项目内容。

---

## 21. F13 设置、主题与高分屏

### 21.1 设置层级

```text
应用默认设置
→ 项目覆盖设置
→ 当前会话临时设置
```

设置分组：通用、编辑器、AI 连接、本地服务、备份、词典与检查、显示与无障碍、高级诊断。

### 21.2 信息架构

六个一级入口：

1. 首页。
2. 规划。
3. 写作。
4. 连续性。
5. 检查与交付。
6. 设置。

三个核心工作台：规划工作台、写作工作台、检查与交付工作台。

### 21.3 写作工作台

```text
左侧：卷/章/场景目录
中间：正文编辑器
右侧：本章上下文、AI 操作、Candidate、连续性提示
底部/顶部轻量状态：保存、字数、AI 任务
```

正文始终占据视觉中心。右栏不使用五层标签堆叠；常用信息按当前任务上下文切换。

### 21.4 响应式规则

- 最低 1280×800。
- 2K 2560×1440 支持 100%、125%、150%。
- 21:9 只扩展留白和辅助面板，不无限拉宽正文。
- 正文宽度为 680/760/860 CSS px。
- `<1100` CSS px：右栏抽屉。
- `<900` CSS px：左右栏均抽屉。
- 禁止页面级横向滚动。

### 21.5 视觉

- 纸面背景、墨色正文、低饱和靛蓝交互色。
- AI 来源用中性灰或蓝紫，不使用绿色表示优越。
- 卡片只用于 Candidate、冲突、风险和恢复。
- 动效 120-200 ms，支持 `prefers-reduced-motion`。

### 21.6 验收效果

- 所有目标分辨率和缩放下无裁切、重叠、横向溢出。
- 多显示器切换后窗口恢复在可见区域。
- 21:9 下危险按钮不远离当前内容。
- 键盘可完成核心编辑、候选采用和对话框操作。

---

## 22. F14 V1.5 分层记忆与 AI 项目日记

该部分不得进入 V1.0 关键路径。

### 22.1 L0-L5

| 层级 | 内容 | 装载策略 |
|---|---|---|
| L0 | 当前选区、当前场景、即时指令 | 始终装载 |
| L1 | 当前章与前章尾快照 | 始终装载 |
| L2 | 当前剧情弧/卷摘要与活跃伏笔 | 按关联装载 |
| L3 | 相关人物、地点、世界规则 | 结构关系优先 |
| L4 | 当前状态与时序历史账本 | 按有效期过滤 |
| L5 | 旧卷、历史 Version、冷资料 | FTS5 按需召回 |

### 22.2 权威边界

摘要、日记和召回结果均为派生数据。它们可以引用权威记录，但不能覆盖正文、设定和当前状态。

### 22.3 项目日记

触发方式：

- 手动生成。
- 章节定稿后事件触发。
- 每 N 章或用户配置周期，在应用运行/项目打开时补执行。

日记内容：本期定稿、确认状态变化、世界规则变化、伏笔进展、风险和下一步关注。每条内容保存来源链接和生成范围。

### 22.4 验收效果

- 历史状态不会覆盖当前状态。
- 修改旧章节会标记相关摘要、检查点和日记为 stale。
- 删除全部摘要和日记后，权威数据仍完整。
- 300 万至 500 万字项目在目标时间内完成打开、检索和约束包组装。

---

## 23. 安全实现规范

### 23.1 Electron

```ts
new BrowserWindow({
  webPreferences: {
    nodeIntegration: false,
    contextIsolation: true,
    sandbox: true,
    webSecurity: true,
    preload,
  },
});
```

- 严格 CSP。
- 阻止 `will-navigate` 到远程页面。
- `setWindowOpenHandler` 默认拒绝，外链走系统浏览器。
- 正式构建禁用开发者工具入口或只在显式诊断模式开启。

### 23.2 路径

所有文件操作执行：

1. `realpath/normalize`。
2. 确认位于允许根目录。
3. 拒绝符号链接逃逸。
4. 拒绝路径穿越和设备路径。
5. 操作完成后再次验证结果路径。

### 23.3 日志

允许：ID、模型标识、耗时、Token 数、状态、错误码、哈希。

禁止：正文、完整 Prompt、凭据、附件内容、模型完整输入输出。

### 23.4 外部 API 最小发送

约束包构建器必须记录发送项类别和字符数，允许用户预览“将发送哪些内容”。默认只发送当前任务需要的信息，不发送整本书。

---

## 24. 性能预算

| 场景 | 指标 |
|---|---|
| 2K 正文输入 | P95 ≤ 50 ms |
| 自动保存事务 | P95 ≤ 150 ms |
| 常规 IPC | P95 ≤ 200 ms |
| 取消反馈 | ≤ 500 ms |
| 5000 字 Candidate 首屏 Diff | ≤ 500 ms |
| 5000 字完整 Diff | ≤ 1.2 s |
| 正文滚动 | ≥ 50 fps |
| Core 单次阻塞 | < 100 ms |
| 10 万字章节首次可编辑 | ≤ 2 s |
| 100 万字全项目 FTS 查询 | P95 ≤ 300 ms（标准测试机） |

性能报告必须写明硬件、项目规模、P50、P95、最差值和与基线差异。

---

## 25. 测试体系

### 25.1 测试层级

- 单元：领域不变量、Diff、Schema、路径、Manifest、Prompt 解析。
- 集成：Repository、事务、写队列、Provider Stub、导入导出、备份恢复。
- E2E：真实 Electron 窗口、编辑、候选、定稿、状态确认、恢复。
- 安全：IPC 越权、路径穿越、恶意 DOCX/ZIP、本地服务包执行边界。
- 迁移：历史 Schema 升级和中断恢复。
- 性能：长章节、百万字项目、2K 渲染、Diff 和 FTS。
- Eval：T0/T1 结构化输出、约束遵循、锁定块保护和连续性质量。

### 25.2 固定工程命令

```json
{
  "scripts": {
    "dev": "pnpm --filter @worldforge/desktop dev",
    "build": "pnpm -r build",
    "lint": "pnpm -r lint",
    "typecheck": "pnpm -r typecheck",
    "test": "pnpm -r test",
    "test:unit": "vitest run tests/unit",
    "test:integration": "vitest run tests/integration",
    "test:e2e": "playwright test",
    "test:security": "vitest run tests/security",
    "test:migration": "vitest run tests/migration",
    "test:perf": "vitest run tests/performance",
    "test:eval": "pnpm --filter @worldforge/prompts eval",
    "test:local-ai": "vitest run tests/integration/local-ai",
    "verify": "pnpm lint && pnpm typecheck && pnpm test && pnpm build"
  }
}
```

### 25.3 P0 必测链路

1. 创建项目 → 编辑 → 重启 → 正文一致。
2. 锁定块 → UI/IPC/AI/批量替换均无法修改。
3. Candidate 生成 → 未接受前 Draft 不变。
4. Candidate 接受 → Revision 冲突时拒绝。
5. 接受后整体撤销 → 重启后恢复点可用。
6. 定稿 → Version 不可更新。
7. 前章返修 → 后续快照 stale，不自动改正文。
8. API Provider 取消/超时/结构错误。
9. 本地服务包损坏/越界/非回环绑定被拒绝。
10. 导入失败无半写入。
11. 备份恢复失败不破坏当前项目。
12. 2K/125%/150% 和 21:9 无布局缺陷。

---

## 26. 开发里程碑

### M0 工程与安全底座

- Monorepo、TypeScript strict、lint、Vitest、Playwright。
- Electron Main/Preload/Renderer 安全骨架。
- Core Utility Process、IPC 信封、错误码。
- app/project SQLite、迁移、WriteQueue。
- 工作空间和路径守卫。

退出条件：安全测试通过，Renderer 无 Node 能力，SQLite 只在 Core。

### M1 编辑与版本核心

- 项目生命周期。
- DraftBlock、Tiptap Schema、BlockPatch。
- 自动保存、Revision、LockGuard。
- Candidate、Diff、接受、撤销、Version。
- 回收站与恢复点。

退出条件：正文安全闭环通过全部 P0 测试。

### M2 规划与连续性

- 任务书、大纲、卷章场景。
- 人物、地点、世界规则。
- 时间线、知情、伏笔。
- 状态提案、章节尾快照、返修 stale。

退出条件：定稿到状态确认闭环可用。

### M3 AI 生成闭环

- 用户 API Provider。
- 本地工作空间服务安装与生命周期。
- 约束包、T0、T1、快速改写、结构性改写。
- 流式、取消、重试、部分 Candidate。
- Prompt Eval。

退出条件：两种 Provider 都能完成 Candidate 闭环，失败不影响编辑。

### M4 修订与交付

- 校验、词典、StoryTodo、批注。
- FTS5 搜索和安全替换。
- TXT/Markdown/DOCX 导入导出。
- 三轨备份、恢复和诊断。
- 设置中心、主题、快捷键、无障碍。

退出条件：完整业务链路可由作者连续使用。

### M5 性能与最终验收

- 2K/21:9/混合 DPI。
- 长章节和百万字数据集。
- 安全、迁移、故障注入和恢复。
- 文档、测试证据和最终验收报告。

### V1.5 独立 Epic

- 分层记忆、时序账本、卷级摘要与检查点。
- AI 项目日记。
- 300 万至 500 万字测试。

不得反向修改 V1.0 的 Candidate、Version、SQLite 权威和作者确认规则。

---

## 27. Codex 使用与配置

### 27.1 推荐启动

交互式本地开发：

```bash
codex --sandbox workspace-write --ask-for-approval on-request
```

执行明确任务卡：

```bash
codex exec \
  --sandbox workspace-write \
  --ask-for-approval on-request \
  "按 docs/tasks/M1-EDITOR-001.md 完成任务，运行任务卡要求的全部测试并提交证据。"
```

`AGENTS.md` 保持简短、准确、可执行。任务细节放入 `docs/tasks/`，架构细节放入本指南和冻结设计文档。

### 27.2 指令加载检查

```bash
codex --ask-for-approval never "列出当前加载的项目指令文件，并概述不可变约束。不要修改文件。"
```

该命令只用于只读检查指令加载，不用于实际编码。

官方参考：

- [Custom instructions with AGENTS.md](https://developers.openai.com/codex/guides/agents-md)
- [Codex best practices](https://developers.openai.com/codex/learn/best-practices)
- [Codex CLI reference](https://developers.openai.com/codex/cli/reference)
- [Codex non-interactive mode](https://developers.openai.com/codex/noninteractive)

---

## 28. AI 编程标准流程

### 28.1 第一步：读取与定位

Codex 必须读取：

1. 根目录 `AGENTS.md`。
2. 当前任务卡。
3. 设计文档中对应功能章节。
4. 相关代码、契约、迁移、测试和历史证据。

不得只根据文件名或旧 TODO 推断现状。

### 28.2 第二步：复述任务

编码前输出：

```text
目标
非目标
受影响模块
数据表/迁移变化
IPC/Schema 变化
安全与数据风险
失败/取消/冲突路径
计划运行的测试命令
```

任务范围明确时继续执行，不因普通实现细节反复等待确认。只有以下情况需要停下：

- 冻结文档之间存在无法自行消解的产品冲突。
- 操作不可逆或将删除用户数据。
- 需要新增生产依赖但任务卡未批准。
- 需要改变数据库权威、AI 接入方式或进程架构。
- 需要访问凭据或超出工作区权限。

### 28.3 第三步：建立失败证据

优先顺序：

1. 写失败测试。
2. 写最小复现脚本。
3. 记录性能基线。
4. 对 UI 缺陷录制可重复的 E2E 步骤。

只有无法自动化时才用手动证据，并写明原因。

### 28.4 第四步：最小完整实现

- 只修改完成任务所需的模块。
- 先领域/契约，再 Repository/Use Case，再 IPC/UI。
- 数据库变化先写迁移和回滚/恢复测试。
- 不以大规模重构掩盖小任务。
- 不引入未来抽象。
- 不留下 TODO、空实现或假成功。

### 28.5 第五步：逐层验证

建议顺序：

```text
受影响包单元测试
→ 集成测试
→ 类型检查
→ lint
→ E2E/安全/迁移/性能专项
→ 根目录 verify
→ 手动业务链路
```

### 28.6 第六步：独立自审

至少检查：

- 是否违反六项不变量。
- 是否存在 Renderer 越权。
- 是否有未校验的 `unknown`。
- 是否遗漏失败、取消、冲突和恢复。
- 是否可能修改锁定块。
- 是否有跨项目 ID 或路径越界。
- 是否将正文/凭据写入日志。
- 是否有迁移不可逆或历史库不兼容。
- 是否有测试只验证 Mock 而未验证真实链路。

高风险任务使用第二个 Codex 会话或 `codex review` 做独立审查。

### 28.7 第七步：同步文档

以下变化必须同步：

- IPC 或公共类型 → `contracts` 与开发指南。
- 数据表 → migration、Schema 文档和测试夹具。
- 业务行为 → 任务卡、设计章节、用户帮助。
- 性能预算 → 基线报告。
- 已知限制 → 完成报告。

### 28.8 第八步：证据化交付

完成报告必须给出：

- 实际修改文件。
- 关键实现说明。
- 实际运行命令和退出码。
- 自动化测试结果。
- 手动验收步骤与结果。
- 数据迁移和恢复结果。
- 性能测量。
- 安全审查结论。
- 未完成项和剩余风险。

没有证据时只能报告“实现中”或“未完成”。

---

## 29. 任务卡模板

```markdown
# <TASK-ID> <任务名称>

## 目标
说明用户可观察到的最终变化。

## 非目标
明确本任务不会改变的范围。

## 设计依据
- V6.6：<章节>
- 开发指南：<章节>
- ADR：<如有>

## 当前问题与复现
给出代码位置、操作步骤、错误或失败测试。

## 影响范围
- packages:
- apps:
- migrations:
- contracts:
- docs:

## 数据库变化
表、字段、索引、迁移、回滚/恢复策略。

## IPC 与 Schema 变化
新增/修改/删除的命令、事件和错误码。

## 实施步骤
按可验证的小步列出。

## 失败、取消、冲突与恢复
逐项说明。

## 安全与隐私
路径、项目范围、锁定、凭据、日志、外部发送内容。

## 自动化测试
列出测试文件与命令。

## 手动验收
按真实作者操作链路列出。

## 性能预算
如不涉及写“不涉及”；涉及则给出阈值和数据集。

## 完成条件
必须是可观察、可测量的结果。
```

---

## 30. 完成报告模板

```markdown
# <TASK-ID> 完成报告

## 结论
完成 / 部分完成 / 未完成

## 实现内容

## 未实现内容

## 修改文件

## 数据库与迁移

## IPC 与契约

## 测试证据
| 命令 | 退出码 | 结果 |
|---|---:|---|

## 手动业务验收

## 性能结果

## 安全与隐私审查

## 已知限制与剩余风险

## 文档同步
```

---

## 31. 变更类型与必跑检查

| 变更类型 | 必跑 |
|---|---|
| 所有变更 | `pnpm lint`、`pnpm typecheck`、`pnpm test`、`pnpm build` |
| 数据库/迁移 | `pnpm test:migration`、`pnpm test:integration` |
| Electron/Preload/IPC | `pnpm test:security`、`pnpm test:e2e` |
| 编辑器/锁定/Revision/Candidate/Version | `pnpm test:unit`、`pnpm test:integration`、`pnpm test:e2e` |
| Prompt/Provider/结构化输出 | `pnpm test:eval`、`pnpm test:integration` |
| 本地模型/服务包 | `pnpm test:local-ai`、`pnpm test:security`、`pnpm test:integration` |
| 导入/备份/恢复 | `pnpm test:integration`、`pnpm test:security`、故障注入 |
| 性能敏感 | `pnpm test:perf` |

---

## 32. 高风险实现检查表

### 32.1 Candidate 接受

- [ ] expectedRevision 校验。
- [ ] baseHash 校验。
- [ ] LockGuard 校验。
- [ ] project/chapter 范围校验。
- [ ] 接受前恢复点。
- [ ] 单事务。
- [ ] 可整体撤销。
- [ ] 冲突不自动覆盖。
- [ ] 来源映射保存。

### 32.2 Version

- [ ] 创建后无 UPDATE 路径。
- [ ] 内容哈希。
- [ ] block 快照完整。
- [ ] 恢复复制成新 Draft。
- [ ] 历史 Version 不受拆章/并章影响。

### 32.3 本地服务包

- [ ] Manifest Zod 校验。
- [ ] 包和文件 SHA-256。
- [ ] 路径穿越/符号链接防护。
- [ ] `shell: false`。
- [ ] 环境变量白名单。
- [ ] 只绑定回环。
- [ ] 健康检查超时。
- [ ] 孤儿进程清理。
- [ ] 卸载不删除项目数据。

### 32.4 导入与恢复

- [ ] 隔离临时目录。
- [ ] 格式与大小限制。
- [ ] 预览后才提交。
- [ ] 提交前恢复点。
- [ ] 中断无半写入。
- [ ] 失败回到原项目。

---

## 33. 反过度设计规则

新增任何抽象、进程、表或依赖前必须回答：

1. 当前哪一个已批准功能需要它？
2. 现有结构为什么无法完成？
3. 有没有更小的直接实现？
4. 它是否把已否决内容重新带回产品？
5. 增加了哪些迁移、测试、恢复和安全成本？
6. 删除它会影响哪个已验收用户流程？

无法给出具体答案时，不实现。

禁止示例：

- 为“以后可能语义检索”建立 Vector Adapter。
- 为“以后可能协作”引入 CRDT 字段。
- 为“以后可能插件”建立动态加载器。
- 为“以后可能上云”建立账户和同步接口。
- 为“以后可能发布”建设 CI/CD、签名和运维平台。
- 为单段改写绕过 Candidate 以追求一次点击。

---

## 34. 最终验收定义

V1.0 只有在以下结果全部成立时才算成品：

1. 单个作者可以从空项目完成规划、写作、AI 候选、编辑、定稿、状态确认、修订、备份和导出。
2. 用户 API 与本地工作空间服务两种 AI 模式均完成真实链路。
3. AI 不会未经确认覆盖正文，锁定块和 Revision 冲突由代码阻断。
4. `project.sqlite` 可独立恢复全部权威数据，缓存和索引可重建。
5. 导入、批量替换、章节拆并、Candidate 接受和恢复均有事务与回退。
6. 2K、混合 DPI、多显示器和 21:9 下界面无严重布局问题。
7. 安全、迁移、E2E、性能和 Eval 门槛全部通过。
8. 文档、代码、Schema、迁移、测试和实际行为一致。
9. 完成报告包含可复核的命令、结果和业务证据。
10. 没有以 Mock、静态界面、TODO 或伪成功代替真实功能。
