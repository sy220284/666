# 数据库规格

## 1. 总原则

- `app.sqlite` 保存应用级注册、设置、Provider 元数据和本地服务安装记录。
- 每个项目的 `project.sqlite` 保存项目全部权威数据和项目内审计记录。
- 所有主键使用不可猜测的文本 ID；所有时间使用 UTC ISO-8601；JSON 字段写入前用 Zod 校验。
- 所有项目表都隐含或显式受当前数据库项目边界保护，跨项目不共享行。
- Version、VersionBlock 无 UPDATE/DELETE 业务路径；删除项目只在用户明确选择后处理项目目录。

## 2. app.sqlite

| 表 | 关键字段 | 约束/索引 |
|---|---|---|
| `app_meta` | `key`, `value` | `key` 主键；保存 schema/version |
| `project_registry` | `id`, `name`, `root_path`, `created_at`, `last_opened_at` | `root_path` 唯一；路径必须规范化 |
| `app_settings` | `key`, `value_json`, `updated_at` | `key` 主键；值经 Schema 校验 |
| `window_states` | `window_key`, `display_id`, `bounds_json`, `scale_factor` | 按窗口键唯一 |
| `provider_profiles` | `id`, `name`, `type`, `base_url`, `model`, `capabilities_json`, `credential_ref`, `local_service_id`, `enabled` | `type` 检查两种值；凭据只保存引用 |
| `local_service_installs` | `service_id`, `version`, `platform`, `arch`, `install_path`, `manifest_hash`, `status` | `(service_id,version,platform,arch)` 唯一 |

## 3. project.sqlite：结构与正文

| 表 | 关键字段 | 主要约束 |
|---|---|---|
| `project_meta` | `project_id`, `name`, `schema_version`, `created_at`, `updated_at` | 单行；`project_id` 与工作空间 Manifest 一致 |
| `volumes` | `id`, `title`, `sort_key`, `deleted_at` | `sort_key` 索引 |
| `chapters` | `id`, `volume_id`, `title`, `sort_key`, `status`, `deleted_at` | 外键卷；标题允许重复但 UI 提示 |
| `scenes` | `id`, `chapter_id`, `title`, `goal`, `conflict`, `outcome`, `sort_key`, `deleted_at` | 外键章节 |
| `drafts` | `id`, `chapter_id`, `revision`, `updated_at` | `chapter_id` 唯一；revision >= 0 |
| `draft_blocks` | `id`, `draft_id`, `logical_block_id`, `scene_id`, `block_type`, `content_json`, `content_hash`, `sort_key`, `locked`, `updated_at` | `(draft_id,logical_block_id)` 唯一；hash 索引 |
| `candidates` | `id`, `chapter_id`, `run_id`, `kind`, `status`, `base_revision`, `prompt_version`, `source_json`, `is_partial`, `created_at`, `resolved_at` | 状态枚举；基线 revision 必填 |
| `candidate_blocks` | `id`, `candidate_id`, `logical_block_id`, `base_hash`, `block_type`, `content_json`, `sort_key`, `change_kind` | 外键 Candidate；稳定排序 |
| `versions` | `id`, `chapter_id`, `kind`, `draft_revision`, `content_hash`, `word_count`, `source_json`, `state_snapshot_id`, `created_at` | 只插入；章节+时间索引 |
| `version_blocks` | `id`, `version_id`, `logical_block_id`, `block_type`, `content_json`, `content_hash`, `sort_key` | 只插入；外键 Version |
| `recovery_points` | `id`, `kind`, `chapter_id`, `version_id`, `metadata_json`, `created_at` | 指向不可变 Version 或一致性备份 |

## 4. 规划与设定

| 表 | 关键字段 | 主要约束 |
|---|---|---|
| `story_brief` | `id`, `premise`, `genre`, `core_conflict`, `protagonist_goal`, `rules_json`, `updated_at` | 单项目一条活动记录 |
| `outlines` | `id`, `parent_id`, `node_type`, `title`, `summary`, `sort_key` | 树结构防循环 |
| `characters` | `id`, `name`, `aliases_json`, `identity`, `motivation`, `voice_notes`, `deleted_at` | 名称规范化索引 |
| `character_relations` | `id`, `from_character_id`, `to_character_id`, `relation_type`, `description` | 禁止自环或按类型校验 |
| `locations` | `id`, `name`, `aliases_json`, `description`, `rules_json`, `deleted_at` | 名称索引 |
| `world_rules` | `id`, `category`, `title`, `content`, `priority`, `deleted_at` | category/priority 索引 |

## 5. 连续性

| 表 | 关键字段 | 主要约束 |
|---|---|---|
| `timeline_events` | `id`, `chapter_id`, `scene_id`, `logical_block_id`, `time_label`, `order_key`, `event_text` | 来源至少一个；order_key 索引 |
| `knowledge_states` | `id`, `character_id`, `fact_key`, `known_from_chapter_id`, `source_ref_json`, `valid_from`, `valid_to` | 角色+事实+有效期索引 |
| `foreshadows` | `id`, `title`, `setup_ref_json`, `target_scope_json`, `status`, `due_chapter_id`, `resolved_ref_json` | 状态枚举 |
| `state_proposals` | `id`, `version_id`, `entity_type`, `entity_id`, `field_key`, `old_value_json`, `new_value_json`, `evidence_json`, `status` | pending/accepted/rejected/edited |
| `state_snapshots` | `id`, `chapter_id`, `version_id`, `snapshot_json`, `is_stale`, `stale_reason`, `created_at` | version 唯一；stale 索引 |

## 6. AI、修订与文件流程

| 表 | 关键字段 | 主要约束 |
|---|---|---|
| `generation_runs` | `id`, `chapter_id`, `provider_profile_id`, `kind`, `status`, `stage`, `sequence`, `received_chars`, `error_code`, `started_at`, `ended_at` | 固定状态；sequence 单调 |
| `validation_issues` | `id`, `chapter_id`, `logical_block_id`, `rule_id`, `severity`, `message`, `evidence_json`, `source`, `status` | 可忽略/静音/恢复 |
| `story_todos` | `id`, `scope_type`, `scope_id`, `title`, `status`, `due_hint`, `created_at` | 状态索引 |
| `comments` | `id`, `chapter_id`, `logical_block_id`, `anchor_json`, `body`, `status`, `created_at` | 锚点校验 |
| `project_dictionary` | `id`, `term`, `aliases_json`, `case_rule`, `notes` | 规范化 term 唯一 |
| `notes` | `id`, `title`, `body`, `source_uri`, `attachment_ref`, `created_at`, `updated_at` | 附件路径受项目边界限制 |
| `import_sessions` | `id`, `source_type`, `source_hash`, `status`, `preview_json`, `error_json`, `created_at` | 提交前隔离 |
| `export_records` | `id`, `format`, `scope_json`, `version_policy`, `target_path`, `content_hash`, `created_at` | 不保存正文副本 |
| `backup_records` | `id`, `kind`, `path`, `manifest_hash`, `size_bytes`, `status`, `created_at` | kind: daily/recovery/manual |
| `trash_entries` | `id`, `entity_type`, `entity_id`, `original_parent_json`, `original_sort_key`, `deleted_at` | 恢复冲突可处理 |
| `project_settings` | `key`, `value_json`, `updated_at` | 项目覆盖应用默认 |

## 7. 派生表

FTS5 虚表、摘要和 V1.5 日记均标记为派生数据。迁移或损坏时清空后从权威表重建。不得建立从派生表回写正文、设定或当前状态的 Use Case。

## 8. 事务边界

Draft Patch、Candidate 接受、Version 创建、章节结构操作、状态提案处理、批量替换、导入提交、恢复切换和迁移必须是单事务。网络调用、模型推理、DOCX 解析、压缩和大型 Diff 不能持有写事务。
