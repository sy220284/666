# 错误码规格

| 错误码 | 含义 | 可自动重试 | 用户处理 |
|---|---|---|---|
| PROJECT_NOT_OPEN | 当前没有活动项目 | 否 | 引导打开项目 |
| PROJECT_SCOPE_VIOLATION | ID 不属于活动项目 | 否 | 拒绝并记录安全事件 |
| PATH_OUT_OF_SCOPE | 路径超出允许目录 | 否 | 要求重新选择目录 |
| REVISION_CONFLICT | Draft Revision 已变化 | 否 | 重新加载并手动解决 |
| LOCKED_BLOCK_MODIFICATION | 操作涉及锁定块 | 否 | 跳过或解锁后重试 |
| CANDIDATE_BASE_MISMATCH | Candidate 基线或哈希不匹配 | 否 | 重新生成 Diff |
| CANDIDATE_PARTIAL_INVALID | 部分候选结构不完整 | 否 | 保存审阅但禁止直接接受 |
| PROVIDER_UNAVAILABLE | Provider 不可用 | 是 | 检查连接后重试 |
| PROVIDER_AUTH_FAILED | 认证失败 | 否 | 更新凭据 |
| PROVIDER_RATE_LIMITED | 限流 | 是 | 按 backoff 重试 |
| PROVIDER_TIMEOUT | 请求超时 | 是 | 允许重试或降低上下文 |
| PROVIDER_OUTPUT_INVALID | 输出不符合 Schema | 有限 | 最多一次受控修复 |
| CREDENTIAL_STORE_FAILED | 凭据无法安全持久化 | 否 | 仅会话使用 |
| LOCAL_SERVICE_PACKAGE_INVALID | 服务包校验失败 | 否 | 删除 partial 并报告原因 |
| LOCAL_SERVICE_START_FAILED | 进程启动失败 | 有限 | 检查平台/日志 |
| LOCAL_SERVICE_HEALTH_TIMEOUT | 健康检查超时 | 有限 | 终止并允许一次重启 |
| LOCAL_SERVICE_STOP_FAILED | 进程无法正常停止 | 有限 | 升级强制终止 |
| GENERATION_CANCELLED | 用户取消 | 否 | 可保存合规 partial |
| IMPORT_UNSAFE_FILE | 导入文件含不安全内容 | 否 | 拒绝 |
| IMPORT_PARSE_FAILED | 解析失败 | 否 | 保留报告，不提交 |
| EXPORT_FAILED | 导出失败 | 是 | 旧文件保持不变 |
| BACKUP_SPACE_INSUFFICIENT | 备份空间不足 | 否 | 保留上一有效备份 |
| DATABASE_INTEGRITY_FAILED | 数据库完整性失败 | 否 | 进入只读诊断/恢复 |
| RESTORE_CONFLICT | 恢复实体与当前结构冲突 | 否 | 显示解决方案 |
| VALIDATION_FAILED | 输入或业务校验失败 | 否 | 显示字段级问题 |
| INVALID_STATE | 状态机不允许当前操作 | 否 | 刷新状态 |

错误对象必须包含 `code`、安全的 `message`、可选 `details` 和 `correlationId`。默认日志只记录错误码、运行 ID 和脱敏上下文。
