# 流式事件协议

## 事件信封

```ts
interface StreamEvent<T> {
  runId: string;
  sequence: number;
  type: 'stage' | 'delta' | 'usage' | 'completed' | 'failed' | 'cancelled';
  emittedAt: string;
  payload: T;
}
```

## 顺序与重订阅

- 每个 Run 的 `sequence` 从 1 单调递增，不得重复或倒退。
- Renderer 记录最后确认的 sequence；重新进入页面时使用 `afterSequence` 重订阅。
- Core 保留有限事件缓冲；若已超出缓冲，返回当前 Run 快照并从新 sequence 继续。
- 切换章节只解除当前视图订阅，不取消 Run。
- 同一 runId 的事件只能进入其绑定章节和候选临时区。

## 批量 Delta

不得逐 Token 发送 IPC。按 30—80ms 或达到字符阈值批量发送；性能测试决定最终参数。Delta 只用于临时显示，权威 Candidate 在 `saving_candidate` 阶段通过 WriteQueue 持久化。

## 取消

取消命令设置 AbortSignal；Provider 停止读取；Core 发送 `cancelled`。若输出结构完整，可保存 `partial` Candidate；默认不可接受，除非通过结构校验并再次确认。

## 清理

Preload 的订阅 API 必须返回 unsubscribe。窗口销毁、项目关闭和 Renderer 卸载时释放 MessagePort 与事件监听，防止重复订阅和内存泄漏。
