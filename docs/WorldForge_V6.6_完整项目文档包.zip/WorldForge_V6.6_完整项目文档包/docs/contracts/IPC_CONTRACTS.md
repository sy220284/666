# IPC 公共契约

## 1. 通用规则

- Renderer 只能通过 Preload 命名 API 调用。
- 每个输入、输出和事件都必须通过 Zod。
- Core 再次校验项目范围、路径、Revision、锁定和状态。
- 普通命令使用 invoke/response；长任务通过 MessagePort 发送事件。
- 所有请求带 `requestId`；写操作带 `projectId` 和必要的幂等键。

## 2. 命令目录

| 命令 | 作用 | 输入 | 输出 | 主要错误 |
|---|---|---|---|---|
| project.create | 创建本地项目 | CreateProjectInput | ProjectSummary | PROJECT_CREATE_FAILED |
| project.open | 打开并锁定项目 | ProjectRef | ProjectBootstrap | DATABASE_INTEGRITY_FAILED |
| project.move | 预览/执行项目移动 | MoveProjectInput | MoveProjectResult | PATH_OUT_OF_SCOPE |
| project.close | 安全关闭项目 | ProjectId | Void | PROJECT_NOT_OPEN |
| planning.bootstrap | 保存建书向导 | StoryBootstrapInput | PlanningSnapshot | VALIDATION_FAILED |
| planning.upsertEntity | 写入规划实体 | PlanningMutation | PlanningEntity | REVISION_CONFLICT |
| editor.loadChapter | 读取章与 Draft | ChapterId | EditorSnapshot | PROJECT_NOT_OPEN |
| editor.applyPatch | 提交 BlockPatch | ApplyPatchInput | ApplyPatchResult | REVISION_CONFLICT |
| editor.setLock | 锁定/解锁块 | SetLockInput | BlockLockResult | LOCKED_BLOCK_MODIFICATION |
| chapter.previewSplit | 生成拆章计划 | SplitRequest | SplitPlan | VALIDATION_FAILED |
| chapter.commitSplit | 提交拆章计划 | PlanCommitInput | StructureResult | REVISION_CONFLICT |
| chapter.previewMerge | 生成并章计划 | MergeRequest | MergePlan | VALIDATION_FAILED |
| chapter.commitMerge | 提交并章 | PlanCommitInput | StructureResult | REVISION_CONFLICT |
| scene.previewMove | 生成跨章移动计划 | MoveSceneRequest | MoveScenePlan | LOCKED_BLOCK_MODIFICATION |
| scene.commitMove | 提交跨章移动 | PlanCommitInput | StructureResult | REVISION_CONFLICT |
| candidate.list | 列出章节候选 | ChapterId | CandidateSummary[] | PROJECT_NOT_OPEN |
| candidate.getDiff | 读取候选 Diff | CandidateId | CandidateDiff | CANDIDATE_BASE_MISMATCH |
| candidate.accept | 接受全部/部分候选 | AcceptCandidateInput | AcceptResult | REVISION_CONFLICT |
| candidate.discard | 丢弃候选 | CandidateId | CandidateSummary | INVALID_STATE |
| version.create | 创建不可变 Version | CreateVersionInput | VersionSummary | REVISION_CONFLICT |
| version.restore | 复制 Version 为新 Draft | RestoreVersionInput | EditorSnapshot | INVALID_STATE |
| ai.provider.list | 列出 Provider Profile | Void | ProviderProfile[] | NONE |
| ai.provider.save | 保存 Profile 元数据 | ProviderProfileInput | ProviderProfile | VALIDATION_FAILED |
| ai.provider.setCredential | 保存凭据 | CredentialInput | CredentialStatus | CREDENTIAL_STORE_FAILED |
| ai.provider.test | 无正文连接测试 | ProviderTestInput | ProviderTestResult | PROVIDER_UNAVAILABLE |
| ai.localService.install | 安装服务包 | InstallServiceInput | LocalServiceInstall | LOCAL_SERVICE_PACKAGE_INVALID |
| ai.localService.start | 启动本地服务 | StartServiceInput | LocalServiceRuntime | LOCAL_SERVICE_START_FAILED |
| ai.localService.stop | 停止本地服务 | ServiceId | Void | LOCAL_SERVICE_STOP_FAILED |
| ai.generation.start | 启动生成 | StartGenerationInput | GenerationRunSummary | PROVIDER_UNAVAILABLE |
| ai.generation.cancel | 取消生成 | RunId | GenerationRunSummary | GENERATION_CANCELLED |
| continuity.list | 读取连续性数据 | ContinuityQuery | ContinuitySnapshot | PROJECT_NOT_OPEN |
| continuity.resolveProposal | 确认/拒绝状态提案 | ResolveProposalInput | StateSnapshot | INVALID_STATE |
| validation.run | 运行校验 | ValidationRequest | ValidationRun | VALIDATION_FAILED |
| validation.resolve | 忽略/静音/恢复问题 | ResolveIssueInput | ValidationIssue | INVALID_STATE |
| search.query | 全文与实体检索 | SearchInput | SearchResultPage | NONE |
| search.previewReplace | 预览安全替换 | ReplaceRequest | ReplacePlan | LOCKED_BLOCK_MODIFICATION |
| search.commitReplace | 提交安全替换 | PlanCommitInput | ReplaceResult | REVISION_CONFLICT |
| import.preview | 解析隔离导入 | ImportPreviewInput | ImportSession | IMPORT_UNSAFE_FILE |
| import.commit | 提交导入 | ImportCommitInput | ImportResult | IMPORT_PARSE_FAILED |
| export.create | 原子导出 | ExportInput | ExportRecord | EXPORT_FAILED |
| backup.create | 创建备份 | BackupInput | BackupRecord | BACKUP_SPACE_INSUFFICIENT |
| backup.restore | 恢复项目 | RestoreBackupInput | RestoreResult | DATABASE_INTEGRITY_FAILED |
| trash.list | 读取回收站 | TrashQuery | TrashEntry[] | NONE |
| trash.restore | 恢复软删除实体 | TrashRestoreInput | EntityRef | RESTORE_CONFLICT |
| settings.get | 读取设置来源 | SettingsQuery | ResolvedSettings | NONE |
| settings.update | 更新应用/项目设置 | SettingsMutation | ResolvedSettings | VALIDATION_FAILED |

## 3. 请求信封

```ts
interface RequestEnvelope<T> {
  requestId: string;
  projectId?: string;
  schemaVersion: 1;
  payload: T;
}
```

## 4. 响应信封

```ts
type ResponseEnvelope<T> =
  | { ok: true; requestId: string; data: T }
  | { ok: false; requestId: string; error: AppError };
```

不得将原始异常栈、SQL、密钥、正文或绝对敏感路径直接返回 Renderer。
