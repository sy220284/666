# 本地 AI 服务包 Manifest 规格

## 1. 目标

Manifest 用于描述可在 WorldForge 本地工作空间中安装和启动的受控模型/服务包。它不是插件接口，也不允许任意脚本执行。

## 2. 示例

```json
{
  "schemaVersion": 1,
  "serviceId": "example.local-model-service",
  "version": "1.0.0",
  "platform": "win32",
  "arch": "x64",
  "entry": "bin/service.exe",
  "args": ["--host", "127.0.0.1", "--port", "${PORT}"],
  "health": {"method": "GET", "path": "/health", "timeoutMs": 15000},
  "api": {"basePath": "/v1", "compatibility": "openai-compatible"},
  "files": [
    {"path": "bin/service.exe", "sha256": "<64-hex>", "size": 123456},
    {"path": "models/model.bin", "sha256": "<64-hex>", "size": 123456789}
  ],
  "resources": {"minMemoryMB": 8192, "recommendedMemoryMB": 16384},
  "packageSha256": "<64-hex>"
}
```

## 3. 校验规则

- `serviceId` 使用反向域名或稳定标识；版本遵循 SemVer。
- `platform` 和 `arch` 必须匹配当前系统。
- `entry` 和所有文件路径必须是规范化相对路径，不含绝对路径、`..`、设备路径和符号链接逃逸。
- `args` 是字符串数组；禁止单个 Shell 命令字符串；只允许 `${PORT}` 等明确占位符。
- 服务必须支持由应用分配的回环端口；禁止声明公网监听。
- 文件数量、单文件大小、总解压大小和压缩比受安全上限控制。
- 包哈希和每个文件哈希全部通过后才能原子安装。

## 4. 生命周期

安装目录为 `local-services/<serviceId>/<version>/`。下载或导入先进入 `.partial`，校验与解压在临时目录完成，最后原子重命名。启动使用 `spawn(..., {shell:false})`，环境变量白名单，健康检查超时后终止。应用退出、项目关闭或卸载时回收进程。
