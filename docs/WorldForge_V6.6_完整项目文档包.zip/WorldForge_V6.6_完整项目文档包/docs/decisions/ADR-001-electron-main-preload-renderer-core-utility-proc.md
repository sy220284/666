# ADR-001 Electron Main + Preload + Renderer + 单一 Core Utility Process

- 状态：已批准
- 基线：V6.6

## 背景

桌面应用需要系统集成、隔离 UI 权限、集中数据库写入和可控 AI 运行。

## 考虑过的方案

- Renderer 直接访问 Node/SQLite
- Main 承担业务逻辑
- 多个常驻 Data/AI/Runtime 进程

## 决策

采用 Main、Preload、Renderer、Core Utility Process 四层；本地 AI 服务是受控可选子进程。

## 后果

- 权限边界清晰
- Core 需要内部 WriteQueue、AsyncRunPool 和 WorkerPool
- 只有量化瓶颈和批准任务才能拆进程

## 重新评估条件

只有出现可复现的架构瓶颈、安全缺陷、平台约束或用户明确改变产品范围时才重新评估。不得因个人偏好或“为以后预留”修改该决策。
