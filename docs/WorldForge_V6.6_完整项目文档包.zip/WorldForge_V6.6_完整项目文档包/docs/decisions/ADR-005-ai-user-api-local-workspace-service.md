# ADR-005 AI 接入限定为 user_api 与 local_workspace_service

- 状态：已批准
- 基线：V6.6

## 背景

用户需要使用自有 API 或本机模型，同时产品不得建设云端中转。

## 考虑过的方案

- WorldForge 请求代理
- 内置云模型服务
- 任意第三种 Provider 插件

## 决策

ProviderType 为封闭联合类型：user_api、local_workspace_service。

## 后果

- 凭据本机加密
- 本地服务受 Manifest 约束
- 新增类型必须修改冻结文档和 Schema

## 重新评估条件

只有出现可复现的架构瓶颈、安全缺陷、平台约束或用户明确改变产品范围时才重新评估。不得因个人偏好或“为以后预留”修改该决策。
