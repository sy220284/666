# 本地构建与打包

## 开发构建

```bash
pnpm install --frozen-lockfile
pnpm lint
pnpm typecheck
pnpm test
pnpm build
```

## 桌面包

实际脚本由 M0/M5 锁定，至少提供 `pnpm package`，输出到明确的本地目录。打包前运行安全、迁移、E2E、性能和 Eval 门禁。

## 包内容检查

- Renderer 不包含 Node/SQLite/凭据访问代码。
- 原生依赖与目标平台匹配。
- 不包含测试密钥、私人作品、调试数据库和未使用模型包。
- LICENSE、第三方声明、版本和安装说明齐全。
- 安装包哈希记录到发布证据。

当前文档不建设云端 CI/CD、签名服务或发布运维平台；正式公开分发涉及的系统签名与公证需另行做发布决策。
