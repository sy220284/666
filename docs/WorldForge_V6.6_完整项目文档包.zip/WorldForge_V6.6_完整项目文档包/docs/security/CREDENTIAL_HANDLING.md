# 凭据处理规范

- Renderer 永远不能读取 API 密钥明文，只能查看“已配置/未配置”。
- Core 通过 Main 的凭据代理调用 Electron `safeStorage`；SQLite 只保存 `credentialRef`。
- safeStorage 不可用或系统环境不安全时，只允许会话内凭据，不得降级为明文 JSON/SQLite。
- 凭据输入后立即从 UI 表单状态清理；不得进入 Redux/Zustand 持久化、崩溃报告或剪贴板日志。
- Provider 请求头在日志中完全脱敏。
- 导出、备份和项目移动不包含凭据存储。
- 删除 Provider Profile 时同步删除对应凭据引用；失败要显示可重试状态。
- 自动化测试使用假凭据和内存凭据存储，禁止把真实密钥提交到仓库。
