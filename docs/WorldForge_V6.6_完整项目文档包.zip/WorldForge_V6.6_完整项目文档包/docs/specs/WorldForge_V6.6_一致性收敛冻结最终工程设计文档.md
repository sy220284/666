% 创世工坊 WorldForge
% V6.6 一致性收敛冻结最终工程设计文档
% Local-first · Author-controlled · Candidate-isolated

**产品目标：** 单个作者在本地完成长篇小说的规划、写作、AI 协作、连续性维护、修订、版本恢复和导出。

**数据边界：** 作品、数据库、索引、日志、备份、配置、模型包与运行记录全部保存在用户本机。

**AI 接入：** 只允许用户配置的模型 API，以及部署在 WorldForge 本地工作空间中的模型/服务两种方式。

**显示基线：** 最低 1280×800；完整支持 2560×1440、100%/125%/150% 缩放、多显示器与 21:9 超宽/曲面屏。

---

# 文档控制

| 项目 | 内容 |
|---|---|
| 文档版本 | V6.6 一致性收敛冻结最终版 |
| 目标产品 | WorldForge V1.0 核心闭环；V1.5 超长篇增强 |
| 目标用户 | 单作者、本地桌面使用；覆盖新手与资深作者 |
| 技术基线 | Electron + React + TypeScript + Tiptap + Core Utility Process + SQLite |
| AI 基线 | `user_api` 与 `local_workspace_service` 两种 Provider |
| 文档状态 | 产品架构、技术选型、功能设计、实现边界和验收标准冻结 |
| 权威规则 | 本文档、AI 编程开发指南与 AGENTS.md 必须保持同一口径 |

# 目录

1. 产品定义与版本范围  
2. 不可变原则与产品边界  
3. 用户与核心创作闭环  
4. 总体架构与模块边界  
5. 技术选型  
6. 本地工作空间与数据架构  
7. 核心功能设计与实现  
8. AI 接入、生成与候选系统  
9. 连续性、修订与长篇记忆  
10. 界面、交互与高分屏适配  
11. 安全、备份与异常恢复  
12. 性能、测试与验收  
13. 开发路线图  
14. 最终关闭条件  
附录 A. 核心数据表  
附录 B. IPC 与错误码  

# 1. 产品定义与版本范围

## 1.1 产品定义

WorldForge 是本地优先的单作者长篇写作工作站。产品聚焦作者在长篇创作中最容易失控的环节：规划与正文分离、AI 结果可审阅、跨章状态可追踪、历史修改可回退、数据始终由作者掌握。

WorldForge 的价值不在于让 AI 自动完成整本书，而在于让 AI 生成、作者判断、正文修改、连续性确认和版本恢复形成安全闭环。

## 1.2 V1.0 完成范围

V1.0 必须形成以下可连续使用的闭环：

```text
创建本地项目
→ 建立任务书、人物、设定、大纲、章节与场景
→ 编辑块级正文并自动保存
→ 调用用户 API 或本地工作空间服务生成 Candidate
→ 对比、局部采用、融合或丢弃
→ 创建不可变定稿 Version
→ 确认状态变化、时间线、知情与伏笔
→ 搜索、校对、批注、备份、恢复与导出
```

## 1.3 V1.5 独立范围

V1.5 在 V1.0 稳定之后实施：

- L0-L5 分层记忆。
- 时序状态历史账本。
- 章节、剧情弧与卷级摘要。
- 卷级检查点和返修改动传播。
- 手动、事件触发和应用运行时定时的 AI 项目日记。
- 300 万至 500 万字压力、召回和失效测试。

V1.5 不引入向量数据库或语义检索平台，仍使用结构化关系与 FTS5。

## 1.4 目标用户

新手作者需要最少填写即可进入第一章，系统提供向导、模板和明确的下一步。

资深作者可以跳过向导和 AI，直接创建空项目、自由写作并按需使用局部工具。

两者共用同一数据模型。所谓“新手模式”和“专业模式”只改变默认入口、字段显隐和解释强度，不产生两套数据和两套功能。

# 2. 不可变原则与产品边界

## 2.1 六项不可变原则

### INV-001 本地数据

正文、设定、数据库、索引、日志、备份、配置、模型包和运行记录只保存在用户本机。外部模型调用由本机直接发起，不经过 WorldForge 服务器。

### INV-002 双 AI 接入

Provider 只有两种：

1. `user_api`：用户配置的兼容模型 API。
2. `local_workspace_service`：下载或导入到本地工作空间并由本机启动的模型/服务。

### INV-003 Candidate 隔离

任何 AI 生成或改写文本先成为 Candidate。未经作者明确接受，不得修改活动 Draft。

### INV-004 SQLite 唯一权威

每个项目的 `project.sqlite` 是正文、规划、状态、候选和版本的唯一权威来源。Renderer 状态、Tiptap JSON、缓存、FTS、摘要、日记和导出文件均为派生数据。

### INV-005 代码硬约束

锁定块、Revision、Version 不可变性、项目边界、路径边界、Candidate 接受和状态确认由 Core 代码强制执行。

### INV-006 作者裁决

AI 可以提出文本、校验问题、状态变化、摘要和日记，但不能直接更新定稿正文、静态设定和权威状态。

## 2.2 产品边界

WorldForge 不建设云存储、云同步、账号后台、作品托管和请求中转。产品不包含多人协作、插件生态、平台发布、读者运营、自动偏好学习和无人审核批量生成。

工程实现不预建向量检索、Embedding/Rerank、MCP 内部总线、CRDT、通用容器平台、CI/CD 发布平台和运维体系。

这些内容不作为“未来候选功能”出现在路线图中，除非用户重新作出明确产品决策并更新冻结文档。

# 3. 用户与核心创作闭环

## 3.1 三种创作路径

| 路径 | 使用方式 | 最短流程 |
|---|---|---|
| 自主写作 | 作者完成正文，AI 只做检查或局部辅助 | 直接写作 → 检查 → 定稿 |
| 混合创作 | 作者确定结构，AI 生成局部场景或过渡 | 场景节拍 → 局部 Candidate → 作者修改 → 定稿 |
| AI 初稿 | 作者先选骨架，再让 AI 扩写整章 | T0 骨架 → T1 正文 → 候选比较 → 定稿 |

每章可独立选择路径，不要求全书保持同一种方式。

## 3.2 核心业务状态

```text
Planning
  └─ 任务书 / 大纲 / 人物 / 规则 / 场景

Draft
  └─ 当前可编辑正文 + Revision + 锁定块

GenerationRun
  └─ AI 任务、真实阶段、流式事件、取消状态

Candidate
  └─ 完整或部分 AI 结果，未确认前与 Draft 隔离

Version
  └─ 不可变定稿或恢复点

StateProposal
  └─ AI/规则提出的状态变化，作者确认后进入当前状态
```

## 3.3 业务成功标准

- 作者可以不配置 AI 完成本地写作、版本和导出。
- 配置任一 AI 模式后，可以生成 Candidate，但正文不会被自动覆盖。
- 章节定稿后，状态变化需要作者逐项确认。
- 返修旧章节会提示后续影响，不自动连锁修改。
- 数据库、索引、备份和导出都可在本机完成。
- 应用异常退出后，已提交编辑仍可恢复。

# 4. 总体架构与模块边界

## 4.1 进程架构

```text
Electron Main
  - 窗口、生命周期、系统菜单、文件选择、外链
  - Core 进程监管
  - 本地 AI 服务进程授权与回收

Preload
  - 白名单业务 API
  - 参数校验和事件订阅释放

Renderer
  - React、Tiptap、Zustand
  - 界面、编辑事务、用户确认、临时流式显示
  - 无 Node、SQLite、文件系统和凭据权限

Core Service Utility Process
  - 唯一 SQLite 写入者
  - Repository、Use Case、FTS5、Provider、校验
  - 导入导出、备份恢复、本地服务包管理

Optional Local AI Service
  - 部署在本地工作空间
  - 只监听 127.0.0.1
```

## 4.2 Main

负责：

- 创建与恢复窗口。
- 系统级文件对话框。
- 外部链接打开。
- 启动、监控和重启 Core。
- 授权启动受控本地 AI 服务。
- 多显示器和 DPI 状态恢复。

禁止：

- 保存正文。
- 直接执行领域 SQL。
- 组装 Prompt。
- 修改 Candidate、Version 和状态。

## 4.3 Preload

Preload 只暴露命名方法，不暴露通用 IPC：

```ts
worldforge.project.open(...)
worldforge.editor.applyPatch(...)
worldforge.ai.startGeneration(...)
worldforge.ai.cancelGeneration(...)
worldforge.backup.create(...)
```

每个方法对应固定 Schema、固定通道和固定返回类型。

## 4.4 Renderer

Renderer 负责：

- 页面与工作台。
- Tiptap 编辑事务。
- 选区、折叠、面板和临时预览。
- 用户确认 Candidate、状态和危险操作。

Renderer 不保存权威正文；Zustand 只保存临时 UI 状态和服务器返回快照。

## 4.5 Core Service

Core 负责：

- `app.sqlite` 与 `project.sqlite`。
- 所有写事务和 Revision。
- Draft、Candidate、Version。
- 规划、连续性、搜索、校验。
- Provider、Prompt、流式任务。
- 本地服务包安装、校验、启动和停止。
- 导入、导出、备份和恢复。

## 4.6 Core 内部并发

Core 不拆成多个 WorldForge 常驻进程，内部使用三条执行通道：

| 通道 | 工作 | 约束 |
|---|---|---|
| SQLite WriteQueue | 所有数据库写入 | 串行、短事务、可记录等待时间 |
| AsyncRunPool | 模型调用、下载、网络 I/O | 不占用数据库事务 |
| WorkerPool | Diff、DOCX 解析、压缩、重索引 | 不阻塞 Core 事件循环 |

# 5. 技术选型

| 层级 | 技术 | 设计理由 | 冻结约束 |
|---|---|---|---|
| 桌面壳 | Electron | 跨平台窗口、文件、进程与系统集成成熟 | `nodeIntegration:false`、`contextIsolation:true`、`sandbox:true` |
| 前端 | React + TypeScript + Vite | 组件化、类型安全、开发反馈快 | Renderer 不可访问 Node |
| 编辑器 | Tiptap + ProseMirror | 支持结构化块、事务、插件和选区 | 只启用最小小说正文 Schema |
| 状态管理 | Zustand | 轻量、适合临时 UI 状态 | 不持久化权威正文 |
| UI 原语 | Radix UI + Tailwind CSS | 无障碍基础和可控视觉 | 保持安静编辑工作台风格 |
| 数据库 | SQLite + better-sqlite3 | 本地单文件、事务、FTS5 | 仅 Core 使用，单写队列 |
| 全文检索 | SQLite FTS5 | 轻量、可重建、无需额外服务 | 不建立向量接口 |
| 契约 | Zod | 运行时校验和类型统一 | IPC、模型输出、Manifest 全覆盖 |
| IPC | Electron IPC + MessagePort | 普通命令与流式事件分离 | 不搭建内部 HTTP 服务 |
| 凭据 | Electron safeStorage | 使用操作系统加密能力 | 不允许明文持久化 |
| 测试 | Vitest + Playwright | 覆盖领域、集成和桌面 E2E | 高风险路径必须故障注入 |
| 本地服务 | child_process.spawn + Manifest | 满足本地工作空间部署 | `shell:false`，只绑定回环地址 |
| Monorepo | pnpm workspace | 包边界和依赖管理清晰 | lockfile 必须提交 |

技术版本在实现时由 lockfile 固定，设计文档不写易过期的版本号。

# 6. 本地工作空间与数据架构

## 6.1 目录结构

```text
<WorldForgeWorkspace>/
├── app.sqlite
├── projects/
│   └── <project-id>/
│       ├── project.sqlite
│       ├── attachments/
│       ├── exports/
│       ├── backups/
│       ├── recovery/
│       └── temp/
├── local-services/
│   └── <service-id>/<version>/
│       ├── manifest.json
│       ├── bin/
│       ├── models/
│       └── logs/
└── logs/
```

## 6.2 app.sqlite 与 project.sqlite

`app.sqlite` 保存：

- 项目注册路径。
- 应用设置。
- 窗口与显示器状态。
- Provider Profile 元数据。
- 本地服务安装记录。
- 加密凭据引用。

`project.sqlite` 保存：

- 卷、章、场景。
- Draft、Block、Candidate、Version。
- 人物、地点、规则、大纲。
- 时间线、知情、伏笔、状态。
- 修订问题、待办、批注、词典。
- 导入、导出、备份与回收站记录。

## 6.3 SQLite 运行参数

```sql
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;
PRAGMA busy_timeout = 5000;
PRAGMA synchronous = NORMAL;
```

每次打开执行 `quick_check`。迁移、恢复和疑似损坏执行 `integrity_check`。

## 6.4 单写队列

所有写操作进入 Core 的单一 WriteQueue。模型调用、下载、DOCX 解析和大型 Diff 不得占用数据库事务。

以下操作必须为单事务：

- Draft Patch。
- Candidate 接受、局部接受和融合。
- Version 创建。
- 章节拆分、合并、跨章移动。
- 状态提案确认。
- 导入提交。
- 恢复切换。
- 数据库迁移。

## 6.5 Revision

- 每章一个活动 Draft。
- 每次成功提交编辑事务，Revision 加一。
- Revision 用于并发和冲突控制，不等于完整历史快照。
- Candidate 保存其 `baseRevision`。
- 接受 Candidate 时必须重新检查当前 Revision、块哈希和锁定状态。

## 6.6 logicalBlockId

`logicalBlockId` 用于追踪同一逻辑段落在 Draft、Candidate 和 Version 中的身份。数据库行 ID 可以变化，逻辑 ID 在内容延续时保持稳定。

它用于：

- 块级 Diff。
- 局部采用。
- 锁定检查。
- 来源追踪。
- 返修影响定位。

## 6.7 Version 不可变

Version 创建后不能更新。恢复历史 Version 时，复制其内容形成新 Draft。任何结构调整只影响当前 Draft 和后续 Version，不修改历史 Version。

## 6.8 FTS5

FTS5 索引正文、设定、时间线、伏笔和笔记。索引是派生数据，损坏或迁移后可以重建，不能反向覆盖权威表。

# 7. 核心功能设计与实现

## 7.1 项目与工作空间

**目标：** 创建、打开、移动、重命名和关闭项目，失败时不产生半项目。

**设计：** 项目目录、数据库和 Manifest 全部初始化成功后，才登记到 `app.sqlite`。移动采用临时复制、校验和原子切换。

**实现：**

- `CreateProject`、`OpenProject`、`MoveProject`、`CloseProject` Use Case。
- 项目级互斥锁。
- 路径规范化和工作空间边界校验。
- 创建失败清理临时目录。

**达到效果：** 移动中断后旧项目仍可打开；Renderer 不能伪造路径打开任意 SQLite 文件。

## 7.2 建书向导与规划

**目标：** 新手五分钟内进入第一章，资深作者可直接空白写作。

**设计：** 向导只采集题材、核心冲突、主角目标、基本规则和第一章目标。完整字段在规划工作台补充。

**实现：**

- `story_brief`、`outlines`、`volumes`、`chapters`、`scenes`。
- 大纲树与场景卡使用稳定 `sort_key`。
- 新手/专业模式共用实体和 Use Case。

**达到效果：** 切换模式不迁移数据，不隐藏已有能力；向导结束后不是空白死页。

## 7.3 人物、地点与世界规则

**目标：** 维护静态设定并为生成与校验提供权威来源。

**设计：** 静态设定与动态状态分开。人物卡保存身份、动机、关系和声音，不直接保存“当前伤势”等可变化内容。

**实现：**

- `characters`、`character_relations`、`locations`、`world_rules`。
- 唯一名称、别名和项目词典联动。
- 任何 AI 提议先形成 Proposal。

**达到效果：** 修改人物静态设定后，后续生成使用新设定；AI 不会直接覆盖人物卡。

## 7.4 场景与章节结构

**目标：** 支持拆章、并章和场景跨章移动，同时保持历史版本和正文安全。

**设计：** 结构操作先生成预览计划，显示正文块、场景、标题和目标章节。确认后单事务执行。

**实现：**

- `SplitChapterPlan`、`MergeChapterPlan`、`MoveScenePlan`。
- 操作前恢复点。
- 锁定块检查。
- 历史 Version 不变。

**达到效果：** 操作失败完整回滚；来源和 logicalBlockId 可追踪。

## 7.5 块级正文编辑

**目标：** 中文长文编辑稳定、自动保存可靠、锁定和撤销可用。

**设计：** 每个顶级正文块对应数据库一行。Tiptap 事务转换为 BlockPatch，由 Core 校验后提交。

**实现：**

- 最小 Schema：段落、三级标题、引用、换行、粗体、斜体。
- IME composition 期间不自动保存。
- 输入停止后批量提交。
- UI 锁定插件 + Core LockGuard。

**达到效果：** 中文输入不丢字、不重复；保存失败不显示假成功；锁定块无法通过任意路径修改。

## 7.6 Candidate 与候选比较

**目标：** AI 结果可选、可弃、可局部采用，不覆盖正文。

**设计：** Candidate 记录基线 Revision、来源、Prompt 版本、运行 ID 和块结构。Diff 以 logicalBlockId 为主，块内文本 Diff 为辅。

**实现：**

- `candidates`、`candidate_blocks`。
- 并排、单稿、只看差异、折叠未改段。
- 逐块接受、全部接受、手工融合和丢弃。
- 大型 Diff 进入 worker。

**达到效果：** 未接受前 Draft 字节级不变；长章节候选可以快速定位改动。

## 7.7 快速改写

**目标：** 单段改写交互轻量，同时保持 Candidate 隔离。

**设计：** 单段生成 `inline_rewrite` Candidate，在原段附近显示差异；用户一次确认后应用。

**实现：**

- 不跨场景和锁定块。
- 大幅结构变化升级到完整候选工作台。
- 接受仍执行标准 Candidate 事务。

**达到效果：** 高频改写不需要进入全屏比较，但数据安全规则不被绕过。

## 7.8 Candidate 接受与撤销

**目标：** 接受操作原子化、冲突可见、可整体撤回。

**设计：** Core 重新读取 Candidate 与当前 Draft，检查 Revision、哈希、锁定和项目范围。接受前创建恢复点。

**实现：**

1. 校验 AcceptPlan。
2. 生成 BlockPatch。
3. 单事务应用。
4. Revision 加一。
5. 保存来源映射。
6. 更新 Candidate 状态。

**达到效果：** Revision 冲突不静默覆盖；Ctrl/Cmd+Z 可整体撤销；重启后可恢复到接受前版本。

## 7.9 定稿 Version

**目标：** 保存不可变章节状态，并作为连续性和导出的稳定来源。

**设计：** 定稿创建 Version 和 VersionBlock，同时记录内容哈希、字数、Draft Revision、Candidate 来源和状态快照版本。

**实现：** Version 表无业务 UPDATE；恢复时复制成新 Draft。

**达到效果：** 历史内容不会被后续编辑、拆章或迁移修改。

## 7.10 时间线、知情和伏笔

**目标：** 追踪跨章连续性，避免人物状态和信息范围错乱。

**设计：**

- 时间线记录事件时间和顺序。
- 知情记录人物何时通过何种来源知道事实。
- 伏笔记录埋设、目标范围、证据和回收状态。

**实现：** 与章节、场景和 logicalBlockId 建立来源关系；生成约束包只装载当前有效信息。

**达到效果：** 模型不会把人物未知事实写入其行为；超期伏笔进入待办而不自动改稿。

## 7.11 章节尾状态确认

**目标：** 定稿后形成下一章可用的当前状态，但保留作者裁决。

**设计：** Version 创建后运行规则/AI 提取状态变化，生成 StateProposal。作者逐项接受、修改或拒绝。

**实现：**

- `state_proposals`、`state_snapshots`、动态状态表。
- 提案确认单事务。
- 返修旧章节后标记后续快照 stale。

**达到效果：** 状态变化可追溯；历史返修只提示影响，不自动改后文。

## 7.12 校验与修订

**目标：** 发现结构、连续性、设定、文风和机械表达风险。

**设计：** 校验分代码确定、规则检查和 AI 辅助三层。AI 结果明确标记为建议。

**实现：**

- `validation_issues`。
- 严重级别、证据、定位块、来源。
- 本章忽略、项目静音、误报恢复。
- StoryTodo 和段落批注。

**达到效果：** 问题可定位、可复查、可降噪；校验系统不直接改正文。

## 7.13 搜索、替换、词典与笔记

**目标：** 快速查找长篇信息，并安全处理批量修改。

**设计：** FTS5 与实体关系并用。批量替换必须预览、排除锁定块和历史 Version。

**实现：**

- FTS 表和重建命令。
- 名称、别名、范围和版本过滤。
- Patch 计划、确认、事务和撤销。
- 项目专名词典。
- 本地文本研究笔记和来源链接。

**达到效果：** 索引可删除重建；实际替换数量与预览一致；历史 Version 不被修改。

## 7.14 导入

**目标：** 将 TXT、Markdown、DOCX 作品安全转换为项目结构。

**设计：** 导入先解析到隔离的 ImportSession，用户调整章节后再提交。

**实现：**

- 编码检测。
- 标题识别建议。
- DOCX 宏、OLE、外链、压缩炸弹和路径穿越检查。
- 提交前恢复点。
- 单事务写入。

**达到效果：** 取消或失败后项目无半写入；复杂 DOCX 有明确降级报告。

## 7.15 导出

**目标：** 导出全书、卷、章节、当前 Draft 或指定 Version。

**设计：** 支持 TXT、Markdown、DOCX。先写临时文件，校验后原子重命名。

**实现：** 导出记录包含范围、版本、字符数和目标路径，不保存正文副本到 app.sqlite。

**达到效果：** 导出失败不覆盖旧文件；导出内容与选择范围一致。

## 7.16 回收站

**目标：** 删除卷、章、场景、笔记和附件后可恢复。

**设计：** 默认软删除。永久删除二次确认并校验项目范围。

**实现：** `trash_entries` 记录实体、原父级和原位置；恢复时处理父级缺失与名称冲突。

**达到效果：** 错删可恢复；伪造 ID 不能删除其他项目内容。

## 7.17 三轨备份与恢复

**目标：** 在纯本地环境中防止数据库损坏、误操作和迁移失败。

**设计：** 日常滚动、重大操作恢复点和手动快照三类备份。

**实现：**

- SQLite Online Backup API。
- Manifest、附件清单和哈希。
- 临时包校验后原子提交。
- 恢复前保护当前项目。
- 恢复后重建 FTS。

**达到效果：** 写入期间备份仍一致；恢复失败不破坏当前项目；磁盘不足不删除上一份有效备份。

## 7.18 设置中心

**目标：** 统一管理应用、项目和会话级设置。

**设计：** 应用默认 → 项目覆盖 → 会话临时设置。

**实现：** 通用、编辑器、AI 连接、本地服务、备份、词典与检查、显示与无障碍、高级诊断八组。

**达到效果：** 设置来源清晰；项目设置不会污染其他项目。

# 8. AI 接入、生成与候选系统

## 8.1 Provider Profile

```ts
type ProviderType = 'user_api' | 'local_workspace_service';

interface ProviderProfile {
  id: string;
  name: string;
  type: ProviderType;
  baseUrl: string;
  model: string;
  capabilities: {
    streaming: boolean;
    structuredOutput: boolean;
    maxContextTokens: number;
    maxOutputTokens: number;
  };
  credentialRef?: string;
  localServiceId?: string;
}
```

能力字段保持最小，不增加推测性标记。

## 8.2 用户 API 模式

- 用户填写端点、模型和凭据。
- Renderer 只显示凭据是否配置。
- 凭据使用 safeStorage，无法安全持久化时只允许会话使用。
- 连接测试使用固定无隐私探针，不发送正文。
- 错误区分认证、模型不存在、限流、超时、证书和输出格式。

## 8.3 本地工作空间服务模式

### 范围

支持下载或导入受控服务包、校验、安装、启动、健康检查、停止和卸载。它不承担容器、驱动、显卡环境和通用模型市场管理。

### Manifest

Manifest 声明：

- Schema 版本。
- 服务 ID、版本和平台。
- 可执行文件相对路径。
- 参数数组。
- 健康检查路径和 API 基础路径。
- 包和文件 SHA-256。
- 模型文件及大小。
- 资源提示。

### 安装

1. 下载或复制到 `.partial`。
2. 检查大小、文件数量和平台。
3. 拒绝绝对路径、`..` 和符号链接逃逸。
4. 校验包和文件哈希。
5. 解压到临时目录。
6. 原子重命名到 `local-services/<id>/<version>`。

### 启动

- 使用 `spawn` 且 `shell:false`。
- 环境变量白名单。
- 随机回环端口。
- 超时健康检查。
- 服务异常退出最多受控重启一次。
- 应用退出和项目关闭时回收子进程。

### 安全效果

损坏包、路径穿越、哈希不符、错误平台、任意 Shell 和非回环监听都被拒绝。

## 8.4 GenerationRun

状态固定：

```text
queued | running | succeeded | failed | cancelled
```

真实阶段：

```text
preparing_context
validating_constraints
waiting_provider
receiving_output
parsing_output
saving_candidate
completed
```

UI 只显示真实阶段、已运行时长和已接收字数，不伪造倒计时。

## 8.5 约束包

```text
P0 代码约束、锁定块、输出 Schema
P1 本章必须事实、场景目标、字数要求
P2 当前权威状态、时间线、知情、伏笔和明确关联设定
P3 人物声音、作品风格和禁用表达
P4 FTS5 补充背景
```

上下文超限时从 P4 开始裁剪，P0 和 P1 不可裁剪。

## 8.6 T0 骨架

T0 输出场景目标、冲突、转折、结果和连续性风险。T0 只能生成骨架 Candidate，不能直接建立定稿正文。

## 8.7 T1 正文

T1 基于作者确认或编辑后的骨架生成块结构。结构化输出失败时只允许一次受控修复；仍失败则保存错误证据，不写入可接受 Candidate。

## 8.8 流式与取消

- delta 按时间或字符量批量发送。
- 每个事件有单调递增 sequence。
- 切换章节不取消任务。
- 重新进入页面可重订阅。
- 取消反馈目标 500 ms。
- 结构完整的部分结果可保存为 partial Candidate，默认不可直接接受。

# 9. 连续性、修订与长篇记忆

## 9.1 V1.0 连续性

V1.0 使用：

- 当前人物状态。
- 时间线。
- 知情信息。
- 伏笔。
- 前章尾快照。
- 结构化关系。
- FTS5 补充召回。

它已经能够支持普通长篇，不需要预建 L0-L5 自动调度。

## 9.2 返修失效传播

旧章节创建新 Version 后，比较其状态影响并标记后续 Snapshot、Issue 和派生摘要 stale。系统只提示受影响范围，作者决定是否重新确认。

## 9.3 V1.5 L0-L5

| 层级 | 内容 | 装载方式 |
|---|---|---|
| L0 | 当前选区、场景和即时指令 | 始终装载 |
| L1 | 当前章和前章尾快照 | 始终装载 |
| L2 | 当前剧情弧/卷摘要、活跃伏笔 | 关联装载 |
| L3 | 相关人物、地点和世界规则 | 结构关系优先 |
| L4 | 当前状态与时序历史账本 | 按有效期过滤 |
| L5 | 旧卷、历史 Version 和冷资料 | FTS5 按需召回 |

## 9.4 AI 项目日记

项目日记记录本期定稿、已确认状态变化、世界规则变化、伏笔进展、风险和下一步关注。触发方式为手动、定稿事件和应用运行期间的周期任务。

日记保存来源链接，是派生数据；删除全部日记不影响权威项目。

# 10. 界面、交互与高分屏适配

## 10.1 视觉定位

“安静的编辑工作台”：纸面背景、墨色正文、低饱和靛蓝交互色、清晰批注感。正文始终是视觉中心。

不使用大面积 AI 蓝背景，不用绿色表示 AI 内容更优，不用发光、弹跳、粒子和持续呼吸动画。

## 10.2 一级入口

1. 首页。
2. 规划。
3. 写作。
4. 连续性。
5. 检查与交付。
6. 设置。

## 10.3 三个核心工作台

### 规划工作台

大纲树、任务书、人物、设定和场景卡集中处理。

### 写作工作台

```text
左侧：卷/章/场景目录
中间：正文编辑器
右侧：本章上下文、AI 操作、Candidate 和连续性提示
轻量状态：保存、字数、AI 运行
```

### 检查与交付工作台

集中处理校验、StoryTodo、批注、搜索、导入导出和备份恢复。

## 10.4 Candidate 审阅

- 全屏双栏。
- 单稿专注。
- 只看差异。
- 折叠未修改段。
- 场景导航。
- 同步滚动与临时解除。
- 冲突块单独处理。

## 10.5 响应式规则

- 最低 1280×800。
- 2560×1440 支持 100%、125%、150%。
- 正文宽度 680/760/860 CSS px。
- 小于 1100 CSS px：右栏抽屉。
- 小于 900 CSS px：左右栏都使用抽屉。
- 页面不出现整体横向滚动。
- 21:9 扩展辅助区域和留白，不无限拉宽正文。
- 危险操作保持靠近当前内容。

## 10.6 主题和无障碍

支持浅色、深色、护眼和高对比主题。使用 SVG 图标、键盘操作、可见焦点、语义标签和 `prefers-reduced-motion`。

# 11. 安全、备份与异常恢复

## 11.1 Electron 安全

```ts
nodeIntegration: false
contextIsolation: true
sandbox: true
webSecurity: true
```

Preload 只暴露命名 API。严格 CSP，阻止远程导航和新窗口，外链由系统浏览器打开。

## 11.2 路径安全

所有路径执行规范化、真实路径解析和允许根目录校验。拒绝路径穿越、符号链接逃逸、设备路径和跨项目路径。

## 11.3 导入安全

DOCX/ZIP 检查：

- 宏。
- OLE。
- 外链和远程资源。
- 展开大小、文件数量和嵌套深度。
- 路径穿越。

## 11.4 凭据和日志

API 密钥不进入 Renderer、SQLite 明文、JSON 和日志。默认日志只记录 ID、模型标识、耗时、Token 数、错误码和哈希，不记录正文与完整 Prompt。

## 11.5 故障恢复

- Core 崩溃：Renderer 进入只读/待恢复状态，Main 重启 Core 后重新同步。
- AI 服务崩溃：编辑器保持可用，GenerationRun 失败，可重试。
- 数据库忙：等待 busy_timeout 后返回可重试错误，不假报保存成功。
- 磁盘不足：停止导入、导出或备份，保留上一份有效数据。
- 迁移失败：回滚并恢复迁移前快照。

# 12. 性能、测试与验收

## 12.1 性能预算

| 场景 | 目标 |
|---|---|
| 2K 正文输入 | P95 ≤ 50 ms |
| 自动保存事务 | P95 ≤ 150 ms |
| 常规编辑 IPC | P95 ≤ 200 ms |
| 取消反馈 | ≤ 500 ms |
| 5000 字 Candidate 首屏 Diff | ≤ 500 ms |
| 5000 字完整 Diff | ≤ 1.2 s |
| 正文滚动 | ≥ 50 fps |
| Core 单次事件循环阻塞 | < 100 ms |
| 10 万字章节首次可编辑 | ≤ 2 s |
| 100 万字 FTS 查询 | P95 ≤ 300 ms（标准测试机） |

## 12.2 测试层级

| 类型 | 验证内容 |
|---|---|
| 单元测试 | 领域规则、Schema、Diff、路径、Manifest、Prompt 解析 |
| 集成测试 | Repository、事务、WriteQueue、Provider、导入、备份恢复 |
| E2E | 真实 Electron 窗口和完整作者流程 |
| 安全测试 | IPC 越权、路径穿越、恶意文件、本地服务包 |
| 迁移测试 | 空库、当前库、历史库和中断升级 |
| 性能测试 | 长章节、百万字项目、2K、Diff、FTS |
| Eval | T0/T1 结构、约束遵循、连续性和降级 |

## 12.3 P0 验收用例

1. 创建项目、编辑、重启后正文一致。
2. 锁定块在 UI、IPC、AI 和批量替换中都不能修改。
3. Candidate 未接受前 Draft 不变。
4. Candidate 接受遇到 Revision 冲突时拒绝并显示冲突。
5. 接受后可整体撤销，重启后可恢复。
6. Version 创建后无法修改。
7. 前章返修只标记后续状态 stale。
8. 用户 API 模式能连接、流式、取消和处理错误。
9. 本地服务模式能安装、启动、健康检查、停止和拒绝恶意包。
10. 导入失败无半写入。
11. 备份恢复失败不破坏当前项目。
12. 2K、125%、150% 和 21:9 无裁切、重叠和横向溢出。

# 13. 开发路线图

## M0 工程与安全底座

- Monorepo 和质量工具。
- Electron 安全骨架。
- Core Utility Process。
- IPC 契约和错误码。
- SQLite、迁移、WriteQueue 和路径守卫。

## M1 编辑与版本核心

- 项目生命周期。
- Tiptap 块模型、自动保存、Revision、锁定。
- Candidate、Diff、接受、撤销、Version。
- 回收站和恢复点。

## M2 规划与连续性

- 任务书、大纲、卷章场景。
- 人物、地点、世界规则。
- 时间线、知情、伏笔。
- 状态提案、章节尾快照和 stale 传播。

## M3 AI 生成闭环

- 用户 API Provider。
- 本地工作空间服务包。
- 约束包、T0、T1、快速改写和结构改写。
- 流式、取消、部分 Candidate 和 Eval。

## M4 修订与交付

- 校验、词典、待办和批注。
- FTS 搜索和安全替换。
- 导入、导出、备份和恢复。
- 设置、主题、快捷键和无障碍。

## M5 性能与最终验收

- 2K、混合 DPI、21:9 和多显示器。
- 长章节和百万字压力。
- 安全、迁移、故障恢复。
- 文档、测试证据和最终验收。

## V1.5 独立 Epic

- L0-L5 和记忆账本。
- 剧情弧/卷摘要与检查点。
- AI 项目日记。
- 300 万至 500 万字验证。

# 14. 最终关闭条件

WorldForge V1.0 只有同时满足以下条件才算完成：

1. 作者可从空项目完成规划、正文、AI Candidate、定稿、状态确认、修订、备份和导出。
2. 用户 API 与本地工作空间服务两种 AI 模式都完成真实业务链路。
3. AI 未经确认不能写入 Draft，锁定块和 Revision 冲突由代码阻断。
4. `project.sqlite` 能恢复全部权威数据，缓存和 FTS 可重建。
5. 导入、章节结构操作、Candidate 接受、批量替换和恢复均有事务与回退。
6. 目标显示矩阵下无严重布局问题。
7. 安全、迁移、E2E、性能和 Eval 全部通过。
8. 设计、开发指南、AGENTS.md、代码、Schema、迁移和测试口径一致。
9. 验收报告提供实际命令、结果、业务证据和剩余风险。
10. 不存在以 Mock、静态界面、TODO 或假成功代替真实功能的情况。

# 附录 A. 核心数据表

| 表 | 用途 | 权威性 |
|---|---|---|
| `volumes`, `chapters`, `scenes` | 项目结构 | 权威 |
| `drafts`, `draft_blocks` | 当前正文与 Revision | 权威 |
| `candidates`, `candidate_blocks` | AI 备选内容 | 权威记录，未接受不影响 Draft |
| `versions`, `version_blocks` | 不可变历史 | 权威 |
| `story_brief`, `outlines` | 任务书和大纲 | 权威 |
| `characters`, `locations`, `world_rules` | 静态设定 | 权威 |
| `timeline_events`, `knowledge_states`, `foreshadows` | 连续性 | 权威 |
| `state_proposals` | 待确认状态 | 非当前权威 |
| `state_snapshots` | 已确认章节尾状态 | 权威 |
| `generation_runs` | AI 运行记录 | 审计记录 |
| `validation_issues`, `story_todos`, `comments` | 修订辅助 | 辅助记录 |
| `project_dictionary`, `notes` | 词典和笔记 | 项目数据 |
| `import_sessions`, `export_records`, `backup_records` | 文件流程 | 审计记录 |
| `fts_*`, `summaries`, `project_diary_entries` | 检索和派生信息 | 可重建、非权威 |

# 附录 B. IPC 与错误码

## 核心 IPC 组

```text
project.*
planning.*
editor.*
candidate.*
version.*
ai.provider.*
ai.localService.*
ai.generation.*
continuity.*
validation.*
search.*
import.*
export.*
backup.*
trash.*
settings.*
```

## 核心错误码

```text
PROJECT_NOT_OPEN
PROJECT_SCOPE_VIOLATION
PATH_OUT_OF_SCOPE
REVISION_CONFLICT
LOCKED_BLOCK_MODIFICATION
CANDIDATE_BASE_MISMATCH
CANDIDATE_PARTIAL_INVALID
PROVIDER_UNAVAILABLE
PROVIDER_AUTH_FAILED
PROVIDER_OUTPUT_INVALID
LOCAL_SERVICE_PACKAGE_INVALID
LOCAL_SERVICE_START_FAILED
LOCAL_SERVICE_HEALTH_TIMEOUT
GENERATION_CANCELLED
IMPORT_UNSAFE_FILE
IMPORT_PARSE_FAILED
BACKUP_SPACE_INSUFFICIENT
DATABASE_INTEGRITY_FAILED
```
