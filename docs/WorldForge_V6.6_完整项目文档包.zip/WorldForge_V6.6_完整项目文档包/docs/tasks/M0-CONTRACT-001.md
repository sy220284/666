# M0-CONTRACT-001 IPC 信封、错误码与事件协议

- 状态：未开始
- 里程碑：M0

## 目标

实现 Zod 契约、Preload 命名 API、请求/响应和 MessagePort 事件。

## 非目标

不暴露 raw ipcRenderer。

## 设计依据

- V6.6 冻结设计文档相关章节。
- AI 编程开发指南。
- AGENTS.md 六项不变量。
- 相关 ADR、数据库、IPC、安全与测试文档。

## 前置依赖

M0-ARCH-001

## 影响范围

packages/contracts; preload; core-service

## 实施要求

1. 先检查现有代码、测试、迁移和契约，记录真实差异。
2. 建立失败测试或可量化复现。
3. 完成前端、Preload、IPC、Use Case、Repository/文件系统和错误路径的最小完整链路。
4. 覆盖失败、取消、冲突、恢复、安全和隐私路径。
5. 更新契约、追踪矩阵、风险、状态与测试证据。

## 必跑检查

```bash
pnpm test:unit
pnpm test:security
pnpm lint
pnpm typecheck
pnpm test
pnpm build
```

## 完成条件

- 目标业务链路使用真实代码和真实数据完成。
- 所有相关不变量测试通过。
- 无 TODO、空实现、假成功或硬编码演示数据。
- 提交命令、退出码、测试数量、手动业务验证和剩余风险。
- 证据写入 `docs/test-evidence/M0/`。
