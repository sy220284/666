# 故障注入计划

| 模块 | 注入点 | 预期 |
|---|---|---|
| WriteQueue | 提交前抛错、busy、进程退出 | 事务回滚，Revision 不增加 |
| Candidate 接受 | 校验后 Draft 被修改 | 返回 REVISION_CONFLICT，无部分应用 |
| Version | 插入 blocks 中断 | 无半 Version |
| 导入 | 解析中断、提交中断 | ImportSession 可诊断，项目无半写入 |
| 备份 | 磁盘不足、哈希失败 | 保留上一有效备份 |
| 恢复 | 切换前失败、校验失败 | 当前项目不变 |
| Provider | 超时、断流、乱序、无效 JSON | 正确错误码或 partial 规则 |
| 本地服务 | 启动失败、健康超时、孤儿进程 | 回收进程并记录状态 |
| 文件系统 | 无权限、路径被替换为 symlink | 拒绝越界，不覆盖外部文件 |
| Renderer | 重载、切章、窗口关闭 | Run 不串流，订阅可恢复 |
