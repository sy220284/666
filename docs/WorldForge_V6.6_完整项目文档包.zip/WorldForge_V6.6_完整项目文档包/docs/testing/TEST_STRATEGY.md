# 测试总策略

## 层级

| 层级 | 重点 |
|---|---|
| 单元 | 领域不变量、Zod、Diff、路径、Manifest、Prompt 解析 |
| 集成 | Repository、事务、WriteQueue、Provider、导入、备份恢复 |
| E2E | Electron 窗口和完整作者工作流 |
| 安全 | IPC 越权、路径穿越、恶意文件、凭据、本地服务包 |
| 迁移 | 空库、当前库、历史库、中断和恢复 |
| 性能 | 2K、长章节、百万字、FTS、Diff、保存和内存 |
| Eval | T0/T1 结构、约束、连续性、降级与模型档案 |

## 门禁

所有任务运行 `pnpm lint && pnpm typecheck && pnpm test && pnpm build`。数据库、IPC、安全、编辑器、AI、本地服务和性能变更按 AGENTS.md 追加专项命令。

P0 失败阻止合并。测试不得只验证 UI 文案；必须验证数据库状态、文件结果、进程状态和恢复路径。

## 证据

每次里程碑将命令、退出码、测试数量、失败修复、性能环境、截图和剩余风险写入 `docs/test-evidence/<MILESTONE>/`。没有证据不得标记完成。
