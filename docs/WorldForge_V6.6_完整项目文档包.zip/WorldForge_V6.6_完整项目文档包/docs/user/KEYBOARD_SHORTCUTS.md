# 键盘快捷键

> 最终键位需在实现时检查 Windows/Linux/macOS 冲突。

| 操作 | Windows/Linux | macOS |
|---|---|---|
| 保存当前编辑事务 | Ctrl+S | Cmd+S |
| 撤销/重做 | Ctrl+Z / Ctrl+Shift+Z | Cmd+Z / Cmd+Shift+Z |
| 项目内搜索 | Ctrl+Shift+F | Cmd+Shift+F |
| 章内查找 | Ctrl+F | Cmd+F |
| 聚焦写作 | F11 或命令面板 | F11 或命令面板 |
| 打开命令面板 | Ctrl+K | Cmd+K |
| 候选比较 | 由上下文命令进入 | 由上下文命令进入 |
| 取消 AI 运行 | Esc（焦点在运行面板） | Esc |

不得覆盖输入法常用组合；所有快捷键必须有菜单或按钮替代。
